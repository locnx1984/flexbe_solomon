#!/usr/bin/env python
# -*- coding: utf-8 -*-
###########################################################
#               WARNING: Generated code!                  #
#              **************************                 #
# Manual changes may get lost if file is generated again. #
# Only code inside the [MANUAL] tags will be kept.        #
###########################################################

from flexbe_core import Behavior, Autonomy, OperatableStateMachine, ConcurrencyContainer, PriorityContainer, Logger
from solomon_flexbe_states.define_dual_arm import DefineDualArmState
from flexbe_states.wait_state import WaitState
# Additional imports can be added inside the following tags
# [MANUAL_IMPORT]

# [/MANUAL_IMPORT]


'''
Created on Tue Oct 20 2020
@author: Loc
'''
class Test_Dual_ArmSM(Behavior):
	'''
	dual robot
	'''


	def __init__(self):
		super(Test_Dual_ArmSM, self).__init__()
		self.name = 'Test_Dual_Arm'

		# parameters of this behavior

		# references to used behaviors

		# Additional initialization code can be added inside the following tags
		# [MANUAL_INIT]
		
		# [/MANUAL_INIT]

		# Behavior comments:



	def create(self):
		# x:893 y:70, x:130 y:365
		_state_machine = OperatableStateMachine(outcomes=['finished', 'failed'])
		_state_machine.userdata.left_joint = [62.52,-101.43,113.52,-102.09,-90,-207.48]
		_state_machine.userdata.right_joint = [53,-109.39,-63.54,-97.08,89.76,-36.93]

		# Additional creation code can be added inside the following tags
		# [MANUAL_CREATE]
		
		# [/MANUAL_CREATE]


		with _state_machine:
			# x:186 y:59
			OperatableStateMachine.add('Define Dual Arm',
										DefineDualArmState(),
										transitions={'done': 'wait 5s'},
										autonomy={'done': Autonomy.Off})

			# x:608 y:44
			OperatableStateMachine.add('wait 5s',
										WaitState(wait_time=5),
										transitions={'done': 'finished'},
										autonomy={'done': Autonomy.Off})


		return _state_machine


	# Private functions can be added inside the following tags
	# [MANUAL_FUNC]
	
	# [/MANUAL_FUNC]
