#!/usr/bin/env python 
# PublishMarkersState: Publishes array of poses from userdata so that they can be displayed in rviz.
#
# Authors: Loc Nguyen 
# Solomon Technology Corp.
# Copyright - 2020 
# 
# The software contains proprietary information of Solomon Technology Corp.  
# It is provided under a license agreement containing restrictions on use and disclosure 
# and is also protected by copyright law. Reverse engineering of the software is prohibited. 
# 
# No part of this publication may be reproduced, stored in a retrieval system, 
# or transmitted in any form or by any means, electronic, mechanical, photocopying, recording or otherwise 
# without the prior written permission of Solomon Technology Corp. 
#  

import rospy
import tf # tf/transformations.py
import copy
import numpy 
from geometry_msgs.msg import Pose
from flexbe_core import EventState, Logger 
from flexbe_core.proxy import ProxyPublisher
from geometry_msgs.msg import PoseStamped 
from geometry_msgs.msg import Vector3 as Vector3Geometry 
from visualization_msgs.msg import Marker,MarkerArray
import rviz_tools_py as rviz_tools


class PublishMarkersState(EventState):
	"""
	Publishes array of poses from userdata so that they can be displayed in rviz.

	-- topic 					string 			Topic to which the pose will be published.
	-- marker_length			float			Length of marker (m)
	-- duration					float			duration in Rviz (seconds)
	-- type						string			types of marker: 

	># detected_objects			VisionDetect		detected objects.

	<= done						Pose has been published.

	"""
	
	def __init__(self, topic,marker_length,duration):
		"""Constructor"""
		super(PublishMarkersState, self).__init__(outcomes=['done'],
													input_keys=['detected_objects']) 
		self._topic = topic 
		self._marker_length = marker_length
		self._duration=duration 
		
		self._markers = rviz_tools.RvizMarkers('/world', self._topic) 
		self.marker_id=0
		
	def execute(self, userdata):  
		"""do nothing in execute()"""
		return 'done' 

	def on_enter(self, userdata):
		"""set base-frame before publishing markers"""
		self._markers.base_frame="/"+str(userdata.detected_objects.result.header.frame_id)
		self._markers.setDefaultMarkerParams() #to make effect on base_frame
		Logger.loginfo("enter rviz %s" %userdata.detected_objects.result.header.frame_id)
		try:  
			if (userdata.detected_objects  is not None):
				current_objects = userdata.detected_objects.result.detections   
				self._markers.deleteAllMarkers()
				for i in range(len(current_objects)):  
					Logger.loginfo('object %d is at %s'%(i+1,current_objects[i].results[0].pose.pose))
					 
					#dipslay Picking obj 
					target_pose =self.pose_to_mat(current_objects[i].results[0].pose.pose)  
					self._markers.publishAxis(target_pose, self._marker_length, self._marker_length*0.1, self._duration) 
					self._markers.publishText(target_pose , "obj "+str(i),'yellow', Vector3Geometry(0.05,0.05,0.05), self._duration) 
					self._markers.publishCube(target_pose, 'red', Vector3Geometry(self._marker_length,self._marker_length,self._marker_length), self._duration) 
			
		except Exception as e:
	 		pass
        
	def on_stop(self):
		"""Stop displaying markers after stopping the state"""		
		try:
			Logger.loginfo("PublishMarkersState on_stop: Clean markers")
			#self._markers.deleteAllMarkers()
		except Exception as e:
			pass

	def mat_to_pose(self,mat):
		"""
		Convert a homogeneous transformation matrix to a ROS Pose msg.
		@param mat 4x4 homogenous transform (numpy.matrix or numpy.ndarray)
		@return pose (ROS geometry_msgs.msg.Pose)
		"""

		pose = Pose()
		pose.position.x = mat[0,3]
		pose.position.y = mat[1,3]
		pose.position.z = mat[2,3]

		quat = tf.transformations.quaternion_from_matrix(mat)
		pose.orientation.x = quat[0]
		pose.orientation.y = quat[1]
		pose.orientation.z = quat[2]
		pose.orientation.w = quat[3]

		return pose
	
	def pose_to_mat(self,pose):
		"""
		Convert a ROS Pose msg to a 4x4 matrix.
		@param pose (ROS geometry_msgs.msg.Pose)
		@return mat 4x4 matrix (numpy.matrix)
		"""

		quat = [pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w]
		pos = numpy.matrix([pose.position.x, pose.position.y, pose.position.z]).T
		mat = numpy.matrix(tf.transformations.quaternion_matrix(quat))
		mat[0:3, 3] = pos

		return mat 