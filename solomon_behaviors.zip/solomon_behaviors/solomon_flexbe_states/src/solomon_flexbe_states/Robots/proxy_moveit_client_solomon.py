#!/usr/bin/env python

import rospy
import actionlib
from threading import Timer
import time
import sys

import moveit_commander
from moveit_msgs.msg import * 

from flexbe_core.logger import Logger
from flexbe_core.proxy import ProxyActionClient


class ProxyMoveitClientSolomon(object):
    """
    A proxy for easily using moveit.
    """
    _is_initialized = False

    _action_topic = "vigir_move_group"

    _robot = None
    _client = None

    def __init__(self):
        if not ProxyMoveitClientSolomon._is_initialized:
            ProxyMoveitClientSolomon._is_initialized = True
            Logger.loginfo("Initializing proxy MoveIt client...")

            moveit_commander.roscpp_initialize(sys.argv)
            ProxyMoveitClientSolomon._robot = moveit_commander.RobotCommander()
            ProxyMoveitClientSolomon._client = ProxyActionClient({ProxyMoveitClientSolomon._action_topic: MoveAction})

        self._goal = None
        self._move_group = ""
        self._result = None
        self._planner_id = "RRTConnectkConfigDefault"
        self._target_link_axis = []


    def new_goal(self, move_group):
        self._move_group = move_group
        self._result = None
        self._goal = MoveGoal()
        self._goal.request.group_name = self._move_group
        self._goal.request.allowed_planning_time = 5.0
        self._goal.request.num_planning_attempts = 1
        self._goal.request.planner_id = self._planner_id
        self._goal.extended_planning_options.target_motion_type = ExtendedPlanningOptions.TYPE_FREE_MOTION
        
        self._goal.extended_planning_options.check_self_collisions = False
        self._goal.extended_planning_options.target_orientation_type = ExtendedPlanningOptions.ORIENTATION_FULL;
        self._goal.extended_planning_options.trajectory_sample_rate = 4.0;       
        
    def start_planning(self):
        for i in range(len(self._goal.extended_planning_options.target_poses)):
            self._goal.extended_planning_options.target_link_axis.append(self._target_link_axis)
            
        self._goal.planning_options.plan_only = True
        ProxyMoveitClientSolomon._client.send_goal(ProxyMoveitClientSolomon._action_topic, self._goal)
        self._goal = None

    def start_execution(self):
        ProxyMoveitClientSolomon._client.send_goal(ProxyMoveitClientSolomon._action_topic, self._goal)
        self._goal = None


    def set_replan(self, value):
        self._goal.planning_options.replan = value

    def set_velocity_scaling(self, value):
        self._goal.request.max_velocity_scaling_factor = value

    def set_collision_avoidance(self, value):
        self._goal.extended_planning_options.allow_environment_collisions = value

    def set_execute_incomplete_plans(self, value):
        self._goal.extended_planning_options.execute_incomplete_cartesian_plans = value

    def set_keep_orientation(self, value):
        self._goal.extended_planning_options.keep_endeffector_orientation = value

    def set_cartesian_motion(self):
        self._goal.extended_planning_options.target_motion_type = ExtendedPlanningOptions.TYPE_CARTESIAN_WAYPOINTS

    def set_circular_motion(self, angle, pitch):
        self._goal.extended_planning_options.target_motion_type = ExtendedPlanningOptions.TYPE_CIRCULAR_MOTION
        self._goal.extended_planning_options.rotation_angle = angle
        self._goal.extended_planning_options.pitch = pitch # meters

    def set_reference_point(self, pose, frame_id):
        self._goal.extended_planning_options.reference_point = pose # Pose msg
        self._goal.extended_planning_options.reference_point_frame = frame_id

    def set_allowed_collision(self, link, target):
        self._goal.extended_planning_options.extended_planning_scene_diff.allowed_collision_pairs.collision_entities = [link, target]
        
    def set_planner_id(self, planner_id):
        self._planner_id = planner_id
        self._goal.request.planner_id = planner_id  
        
    def set_drake_target_link_names(self, link_names):
        self._goal.extended_planning_options.target_link_names = link_names
        
    def set_drake_target_pose_times(self, pose_times):
        self._goal.extended_planning_options.target_pose_times = pose_times
            
    def set_drake_check_self_collisions(self, check_self_collisions):
        self._goal.extended_planning_options.check_self_collisions = check_self_collisions
            
    def set_drake_target_orientation_type(self, orientation_type):
        self._goal.extended_planning_options.target_orientation_type = orientation_type
        
    def set_drake_trajectory_sample_rate(self, sample_rate):
        self._goal.extended_planning_options.trajectory_sample_rate = sample_rate
        
    def set_drake_target_link_axis(self, link_axis):		
        self._target_link_axis = link_axis;

    def add_joint_values(self, joint_values):
        joint_names = ProxyMoveitClientSolomon._robot.get_joint_names(self._move_group)
        if len(joint_names) != len(joint_values):
            Logger.logwarn("Amount of given joint values (%d) does not match the amount of joints (%d)." % (len(joint_values), len(joint_names)))
            #return

        goal_constraints = Constraints()
        for i in range(len(joint_names)):
            goal_constraints.joint_constraints.append(JointConstraint(joint_name=joint_names[i], position=joint_values[i]))

        self._goal.request.goal_constraints.append(goal_constraints)

    def add_endeffector_pose(self, target_pose, frame_id = "/world"):
        self._goal.extended_planning_options.target_frame = frame_id
        self._goal.extended_planning_options.target_poses.append(target_pose)

    def add_link_padding(self, link_paddings):
        for link_name, padding in link_paddings.iteritems():
            link_padding = LinkPadding(link_name = link_name, padding = padding)
            self._goal.planning_options.planning_scene_diff.link_padding.append(link_padding)

    def finished(self):
        if ProxyMoveitClientSolomon._client.has_result(ProxyMoveitClientSolomon._action_topic):
            self._result = ProxyMoveitClientSolomon._client.get_result(ProxyMoveitClientSolomon._action_topic)
            return True
        return False

    def success(self):
        return self._result.error_code.val == MoveItErrorCodes.SUCCESS

    def error_msg(self):
        for key, value in MoveItErrorCodes.__dict__.items():
            if value == self._result.error_code.val and key[0] != "_":
                return key + (" (%s)" % str(self._result.error_code.val))
        return "unknown error (%s)" % str(self._result.error_code.val)

    def cancel(self):
        ProxyMoveitClientSolomon._client.cancel(ProxyMoveitClientSolomon._action_topic)

    def get_plan(self):
        return self._result.planned_trajectory.joint_trajectory

    def get_plan_fraction(self):      
        return self._result.extended_planning_result.plan_completion_fraction
