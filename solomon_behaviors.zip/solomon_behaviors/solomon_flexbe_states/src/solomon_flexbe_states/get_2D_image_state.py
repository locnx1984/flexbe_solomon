#!/usr/bin/env python
# 
# Get2DImageState: Grabs the most recent camera image.
#
# Authors: Loc Nguyen 
# Solomon Technology Corp.
# Copyright - 2020 
# 
# The software contains proprietary information of Solomon Technology Corp.  
# It is provided under a license agreement containing restrictions on use and disclosure 
# and is also protected by copyright law. Reverse engineering of the software is prohibited. 
# 
# No part of this publication may be reproduced, stored in a retrieval system, 
# or transmitted in any form or by any means, electronic, mechanical, photocopying, recording or otherwise 
# without the prior written permission of Solomon Technology Corp. 
#  

import rospy
from flexbe_core import EventState, Logger

from flexbe_core.proxy import ProxySubscriberCached

from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2 
class Get2DImageState(EventState):
	'''
	Grabs the most recent camera image.

	-- image_topic	string	the topic that publish images
	#> camera_img 	Image 	The current color image of the left camera.

	<= done 				Image data is available.

	'''

	def __init__(self,image_topic):
		'''Constructor'''
		super(Get2DImageState, self).__init__(outcomes = ['done'],
														output_keys = ['camera_img'])
		#self.bridge = CvBridge()
		self._img_topic = image_topic
		self._sub = ProxySubscriberCached({self._img_topic: Image})

	def execute(self, userdata):
		Logger.loginfo("excexute!")
		if self._sub.has_msg(self._img_topic):
			img2D = self._sub.get_last_msg(self._img_topic)

			# try: 
			# 	image_buff = CvBridge().imgmsg_to_cv2(img2D, "bgr8") 
			# 	cv2.namedWindow("window")
      		# 	cv2.imshow("window", image_buff)  

			Logger.loginfo("Get 2D image! width %d height %d" %(img2D.width,img2D.height))			
			userdata.camera_img=img2D
			return 'done'


	def on_enter(self, userdata):
		Logger.loginfo("enter!")
		pass