#!/usr/bin/env python

import rospy

import moveit_commander
import sys 
# print(sys.path) 
sys.path.append('../../../../') #for solomon_pack and solomon_functions
from flexbe_core import EventState, Logger

from flexbe_core.proxy import ProxySubscriberCached

from Robots.solrobot_class import SolRobot,SolDualArm  #run in terminal
#from src.solomon_behaviors.solomon_flexbe_states.src.solomon_flexbe_states.Robots.solrobot_class import SolRobot,SolDualArm
'''
Created on 10/15/2020

@author: Loc Nguyen
'''
class DefineARobotState(EventState):
	'''
	Grabs the most recent camera image.

	#> camera_img 	Image 	The current color image of the left camera.

	<= done 				Image data is available.

	'''

	def __init__(self):
		'''Constructor'''
		super(DefineARobotState, self).__init__(outcomes = ['done'],
														input_keys = ['robot_name'],
														output_keys = ['robot']) 

	def execute(self, userdata): 
		return 'done'


	def on_enter(self, userdata):
		Logger.loginfo("enter!") 
		userdata.robot=SolRobot(userdata.robot_name)
        #Logger.loginfo("Robot is ready %s"%str(userdata))
	    #userdata.camera_img=img2D  