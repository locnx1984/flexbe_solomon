#!/usr/bin/env python
# -*- coding: utf-8 -*-
###########################################################
#               WARNING: Generated code!                  #
#              **************************                 #
# Manual changes may get lost if file is generated again. #
# Only code inside the [MANUAL] tags will be kept.        #
###########################################################

from flexbe_core import Behavior, Autonomy, OperatableStateMachine, ConcurrencyContainer, PriorityContainer, Logger
from flexbe_states.log_state import LogState
from solomon_flexbe_states.clear_octomap import ClearOctomapState
from vigir_flexbe_states.moveit_planning_state import MoveitPlanningState
# Additional imports can be added inside the following tags
# [MANUAL_IMPORT]

# [/MANUAL_IMPORT]


'''
Created on Mon Nov 02 2020
@author: Loc
'''
class Test_FlexSM(Behavior):
	'''
	abc
	'''


	def __init__(self):
		super(Test_FlexSM, self).__init__()
		self.name = 'Test_Flex'

		# parameters of this behavior

		# references to used behaviors

		# Additional initialization code can be added inside the following tags
		# [MANUAL_INIT]
		
		# [/MANUAL_INIT]

		# Behavior comments:



	def create(self):
		# x:768 y:388, x:130 y:365
		_state_machine = OperatableStateMachine(outcomes=['finished', 'failed'])
		_state_machine.userdata.joint1 = [0,0,0,0,0,0.1]

		# Additional creation code can be added inside the following tags
		# [MANUAL_CREATE]
		
		# [/MANUAL_CREATE]


		with _state_machine:
			# x:143 y:104
			OperatableStateMachine.add('print1',
										LogState(text="hello world solomon", severity=Logger.REPORT_HINT),
										transitions={'done': 'clear0'},
										autonomy={'done': Autonomy.Off})

			# x:514 y:68
			OperatableStateMachine.add('clear0',
										ClearOctomapState(service_topic="/robot0/clear_octomap", times=3),
										transitions={'done': 'abc', 'failed': 'failed'},
										autonomy={'done': Autonomy.Off, 'failed': Autonomy.Off})

			# x:461 y:351
			OperatableStateMachine.add('abc',
										MoveitPlanningState(planning_group="robot0", vel_scaling=0.1),
										transitions={'planned': 'finished', 'failed': 'failed'},
										autonomy={'planned': Autonomy.Off, 'failed': Autonomy.Off},
										remapping={'joint_values': 'joint1', 'joint_trajectory': 'joint_trajectory'})


		return _state_machine


	# Private functions can be added inside the following tags
	# [MANUAL_FUNC]
	
	# [/MANUAL_FUNC]
