#!/usr/bin/python
#
# Demo: Dual Arm
# Authors: Loc Nguyen, Eric Huang, Hank Tsai, Frank Lu
# Solomon Technology Corp.
# Copyright - 2020 
# 
# The software contains proprietary information of Solomon Technology Corp.  
# It is provided under a license agreement containing restrictions on use and disclosure 
# and is also protected by copyright law. Reverse engineering of the software is prohibited. 
# 
# No part of this publication may be reproduced, stored in a retrieval system, 
# or transmitted in any form or by any means, electronic, mechanical, photocopying, recording or otherwise 
# without the prior written permission of Solomon Technology Corp. 
#  
from __future__ import print_function
import threading
import time
import numpy as np
import random
import math
from argparse import ArgumentParser 
#Moveit
import copy
import sys
sys.path.append('../../../../../') #for referencing solomon_pack, solomon_functions
sys.path.append('../../../../') 
sys.path.append('../../../') 
sys.path.append('../../') 
sys.path.append('/media/solomon/28CECBCACECB8F0E3/LOC/DualArm/Solomon_Motion_Planning/src/') 

from solomon_pack.packer import SolPalletization
from solomon_functions.box_localization_func import BoxLocalization
from solomon_functions.robodk import *
from solomon_functions.solomon_math import *

import re
import rospy
import rospkg
import rosnode
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from std_msgs.msg import String
from std_msgs.msg import Empty as Empty_msg
from std_srvs.srv import Empty 
from shape_msgs.msg import SolidPrimitive
from moveit_msgs.msg import PlanningScene, PlanningSceneWorld, CollisionObject
from moveit_msgs.msg import RobotState, RobotTrajectory, DisplayTrajectory
from moveit_msgs.msg import Constraints, OrientationConstraint  
from moveit_msgs.srv import GetPositionIK, GetPositionIKRequest, GetPositionFK, GetPositionFKRequest
from trajectory_msgs.msg import JointTrajectoryPoint 
import std_msgs, std_msgs.msg

from vision_msgs.msg import Detection3D, Detection3DArray, ObjectHypothesisWithPose
from visualization_msgs.msg import Marker, MarkerArray
from sensor_msgs.msg import Image, CameraInfo
from cv_bridge import CvBridge, CvBridgeError
import cv2
from geometry_msgs.msg import PoseStamped 
from geometry_msgs.msg import Point as PointGeometry
from geometry_msgs.msg import Pose as PoseGeometry
from geometry_msgs.msg import Quaternion as QuaternionGeometry
from geometry_msgs.msg import Vector3 as Vector3Geometry
import roslib; roslib.load_manifest('ur_driver')
import actionlib 
import tf
#condition terminals:
#~/dual_arm/Solomon_Motion_Planning$ roslaunch solomon_config run_all_dual_arm.launch sim:=false detect:=false 
#~/dual_arm/Solomon_Motion_Planning$ roslaunch dual_arm_config moveit_rviz.launch 
#Source: 
#CLEAR OCTOMAP: rosservice call /clear_octomap
# source ../../../../../../devel/setup.bash 

# SetIO for Robot
from ur_msgs.srv import SetIO
#from ur_io_wrapper import IOWrapper
from scene_interface.scene_interface import SceneInterfaceSol   #=======================NOTE
from solomon_msgs.srv import VisionDetect   #=======================NOTE
from solomon_msgs.msg import PlanningAction
 
#~/dual_arm/Solomon_Motion_Planning$ roslaunch dual_arm_config dual_arm_moveit_planning_execution.launch sim:=false
#~/dual_arm/Solomon_Motion_Planning$ roslaunch dual_arm_config moveit_rviz.launch 

from flexbe_core import EventState, Logger
import rviz_tools_py as rviz_tools

class SolRobot(object):
    _is_initialized = False
    _ns_dict={} # dictionary {ns:[movegroup_commander,robot_commander,scene]}

    def __init__(self, ns=''):
        self.name_space=ns
        self.robot_name="robot" 
        self.tcp0_name=ns+'/tcp0'  


        if not SolRobot._is_initialized:
            SolRobot._is_initialized = True
            
            Logger.loginfo("SolRobot:Initializing proxy MoveIt client...")
            moveit_commander.roscpp_initialize(sys.argv)

        if (ns not in SolRobot._ns_dict):
            Logger.loginfo('Instantiate a RobotCommander object...') 
            _robot= moveit_commander.RobotCommander(robot_description=ns+'/robot_description', ns=ns)
            Logger.loginfo('Instantiate a MoveGroupCommander object...')
            _group_name=_robot.get_group_names()[0]
            _move_group = moveit_commander.MoveGroupCommander(_group_name, robot_description=ns+'/robot_description', ns=ns)
            _move_group.set_max_velocity_scaling_factor(1)
            _move_group.set_max_acceleration_scaling_factor(1)
            _move_group.set_planning_time(1.5)
            Logger.loginfo('Instantiate a PlanningSceneInterface object...')
            _scene = SceneInterfaceSol(ns=ns)
            # Adding a new key value pair
            SolRobot._ns_dict.update({ns: [_robot,_move_group,_scene]})

        Logger.loginfo("----------------SolRobot._ns_dict:")
        for keys,values in SolRobot._ns_dict.items():
            print(keys)
            print(values)
        Logger.loginfo("----------------END")
        #Get from dictionary
        self.robot,self.move_group,self.scene  =SolRobot._ns_dict[ns] 
        self.group_name=self.robot.get_group_names()[0]
        self.link_names = self.robot.get_link_names(self.group_name)
 
        Logger.loginfo("Link names= %s" %self.robot.get_link_names())  
       
        self.joint_names = self.move_group.get_joints()[:-1] 
        Logger.loginfo("Joint Names= %s"%self.joint_names)
        Logger.loginfo('Finish setting Move_Group@') 
         
        self.move_group.set_end_effector_link(self.tcp0_name) 
        self.eef_link = self.move_group.get_end_effector_link() 
        self.move_group.set_pose_reference_frame("world") 
         

        self.planned_path=None
        self.planned_path_cube_num=0
        self.recent_path=[] 
 

    def print_out(self):
        Logger.loginfo("---------robot info------------------")
        Logger.loginfo("---------robot name: %s" %self.robot_name)  
        Logger.loginfo("---------group_name: %s" %self.group_name)  
        Logger.loginfo("---------joint_names: %s" %self.joint_names)  
        Logger.loginfo("---------tcp0_name: %s" %self.tcp0_name)  
    def get_V2R(self):
        # get V2R form rosparam spend ~= 10-20ms
        ns='camera/solomon'
        param_name='robot_to_camera'
        v2r_x= rospy.get_param('{}/{}/x'.format(ns, param_name))
        v2r_y = rospy.get_param('{}/{}/y'.format(ns, param_name))
        v2r_z = rospy.get_param('{}/{}/z'.format(ns, param_name))
        v2r_rx = rospy.get_param('{}/{}/rx'.format(ns, param_name))
        v2r_ry = rospy.get_param('{}/{}/ry'.format(ns, param_name)) 
        v2r_rz = rospy.get_param('{}/{}/rz'.format(ns, param_name)) 
        return xyzrpw_2_pose([v2r_x, v2r_y, v2r_z, v2r_rx*180/pi, v2r_ry*180/pi, v2r_rz*180/pi]) #m

    def get_world2robot(self):
        #get robot to world
        #Note: type is robodk mat
        tf_listener = tf.TransformListener()  
    
        rate = rospy.Rate(2)
        transform=None
        while not rospy.is_shutdown() and  transform is None:
            try: 
                transform = tf_listener.lookupTransform('/world', self.robot_name+'/robot', rospy.Time(0)) 
                rospy.logdebug("world_T_robot transformation {}". format(transform))
    
                print(transform)
            except  (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException) as e:
                rospy.logwarn(e)
            rate.sleep()
        rospy.logdebug("got transformation") 
    
        #Get World==>Robot Transform
        mat_worlf2robot=xyz_quaternion_2_np_array(transform[0],transform[1]) 
        return array_2_pose(np.linalg.inv(mat_worlf2robot))  

    def get_pose_tcp0(self):
        #get robot to world
        #Note: type is robodk mat
        tf_listener = tf.TransformListener()  
    
        rate = rospy.Rate(2)
        transform=None
        while not rospy.is_shutdown() and  transform is None:
            try: 
                transform = tf_listener.lookupTransform(self.robot_name+'/world', self.robot_name+'/tcp0', rospy.Time()) 
                rospy.logdebug("world_T_robot transformation {}". format(transform))
    
                print('transform ', transform)
            except  (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException) as e:
                rospy.logwarn(e)
            rate.sleep()
        rospy.logdebug("got transformation") 
    
        #Get World==>Robot Transform
        mat_worlf2robot=xyz_quaternion_2_np_array(transform[0],transform[1]) 
        return array_2_pose(np.linalg.inv(mat_worlf2robot)) 
     
    def cartesian_plan(self,goal_pose): 
        
        current_pose=self.current_robot_pose()
        count_retry=0 
        while (different_pose(current_pose,goal_pose)>0.004):  
            diff_pose=different_pose(current_pose,goal_pose)

            waypoints = [] 
            waypoints.append(copy.deepcopy(goal_pose)) 
            count_retry+=1
            
            (plan, fraction) = self.move_group.compute_cartesian_path(
                                            waypoints,   # waypoints to follow
                                            0.01,        # eef_step
                                            0.0)         # jump_threshold
            rospy.logwarn('cartesian fraction {}'.format(fraction))  
             
            if (count_retry%3 ==0):
                self.clear_octomap()
                print("Reset Octomap...")
                rospy.sleep(.1)
 
            self.move_group.execute(plan, wait=True)
            current_pose=self.current_robot_pose()
            print("cartesian: count_retry=",count_retry, "dif=",diff_pose, "goal pose=\n",goal_pose)  
            print("cartesian: current_pose=\n",current_pose)

        return current_pose 

    def test_cartesian_plan(self): 
        
        wpose=self.move_group.get_current_pose().pose#self.current_robot_pose() 

        waypoints = [] 
        waypoints.append(copy.deepcopy(wpose)) 
        scale=0.3
        wpose.position.z -= scale * 0.1  # First move up (z)
        wpose.position.y += scale * 0.11  # and sideways (y)
        waypoints.append(copy.deepcopy(wpose))

        wpose.position.x += scale * 0.1  # Second move forward/backwards in (x)
        waypoints.append(copy.deepcopy(wpose))

        wpose.position.y -= scale * 0.1  # Third move sideways (y)
        waypoints.append(copy.deepcopy(wpose))

        (plan, fraction) = self.move_group.compute_cartesian_path(
                                        waypoints,   # waypoints to follow
                                        0.01,        # eef_step
                                        0.0)         # jump_threshold
        rospy.logwarn('cartesian fraction {}'.format(fraction))  
        #------
        self.move_group.execute(plan, wait=True)
        current_pose=self.current_robot_pose() 
        print("cartesian: current_pose=\n",current_pose)

        return current_pose  
    
    def current_robot_pose(self):
        return self.move_group.get_current_pose().pose
        #return pose_2_geometry_msgs_Pose(self.world2robot.__mul__(geometry_msgs_Pose_2_pose(self.move_group.get_current_pose().pose)))
    
    def add_marker(self):
        #rospy.init_node('ellipse', anonymous=True)
        publisher = rospy.Publisher("visualization_marker", MarkerArray, queue_size=100)
        count = 0
    
        markerArray = MarkerArray()
        MARKERS_MAX = 10
        if not rospy.is_shutdown():
            for i in range(MARKERS_MAX):
                marker = Marker()
                marker.header.frame_id = "/"+self.robot_name;
                marker.type =  Marker.SPHERE
                marker.action = Marker.ADD
                marker.scale.x = 0.01
                marker.scale.y = 0.01
                marker.scale.z = 0.01
                marker.color.a = 1.0
                marker.color.r = 1.0
                marker.color.g = 0.0
                marker.color.b = 0.0
                marker.pose.orientation.w = 1.0
                marker.pose.position.x = -0.5+random.uniform(-0.1, 0.1)
                marker.pose.position.y = 0
                marker.pose.position.z = 0.5+random.uniform(-0.2, 0.2)
                # We add the new marker to the MarkerArray, removing the oldest marker from it when necessary
                if(count > MARKERS_MAX):
                    markerArray.markers.pop(0)
                markerArray.markers.append(marker)
    
            # Renumber the marker IDs 
            id = 0
            for m in markerArray.markers:
                m.id = id
                id += 1
            print("MARker NUM=",id) 
            # Publish the MarkerArray
            publisher.publish(markerArray)
    
            rospy.sleep(0.01)
            #rospy.spin();
    
    def copy_geometry_msgs_Pose(self,original_pose, offset=(0,0,0)):
        copy_pose= geometry_msgs.msg.Pose()
        copy_pose.orientation.x =original_pose.orientation.x
        copy_pose.orientation.y =original_pose.orientation.y
        copy_pose.orientation.z = original_pose.orientation.z
        copy_pose.orientation.w = original_pose.orientation.w
        copy_pose.position.x =  original_pose.position.x+offset[0]
        copy_pose.position.y = original_pose.position.y+offset[1]
        copy_pose.position.z = original_pose.position.z+offset[2]
        return copy_pose

    def get_targeting_object(self, dz_approach=-0.25,dz_leave=0.25):
        approach_pose = PoseStamped() 
        target_pose = PoseStamped() 
        leave_pose  = PoseStamped()  
    
        #bin center
        bx=self.bin_right_center[0]
        by=self.bin_right_center[1]
        bz=self.bin_right_center[2]
        # global current_objects 
       
        object_available=False
        box_size=None 
       

        while (object_available is False):
            # call service
            print("call service...........................")
            res=None
            res = self.detect_proxy()
            current_objects = res.result.detections
            self.detected_targets=[]
    
            max_z_index=-1
            max_z_value=-1000000
            
            for i in range(len(current_objects)): 
                x=current_objects[i].results[0].pose.pose.position.x #+0.02
                y=current_objects[i].results[0].pose.pose.position.y 
                z=current_objects[i].results[0].pose.pose.position.z 

                print(i," pose=",x,y,z)
                if ((bx-x)*(bx-x) <0.35*0.35) and ((by-y)*(by-y) <0.25*0.25)  and  z>(bz) and  z<0.2:
                    self.detected_targets.append(geometry_msgs_Pose_2_pose(current_objects[i].results[0].pose.pose))

                    #if (z>max_z_value): #get highest z object 
                    if (-abs(self.world2robot.Pos()[0]-x)>max_z_value):
                        max_z_index=i
                        max_z_value=-abs(self.world2robot.Pos()[0]-x)
    
            #find available picking target
            if(max_z_index>-1):  
                x=current_objects[max_z_index].results[0].pose.pose.position.x #+0.02
                y=current_objects[max_z_index].results[0].pose.pose.position.y 
                z=current_objects[max_z_index].results[0].pose.pose.position.z 
      
                box_thickness_z=z-bz  
                dz_leave=-dz_approach+box_thickness_z
                approach_pose = copy.deepcopy(current_objects[max_z_index].results[0].pose)
                target_pose= copy.deepcopy(current_objects[max_z_index].results[0].pose)
                leave_pose = copy.deepcopy(current_objects[max_z_index].results[0].pose)
                approach_pose.pose.position.z-=dz_approach
                leave_pose.pose.position.z-=dz_approach-box_thickness_z 

                #get orientation: remain the orientation
                #self.pick_pose=geometry_msgs_Pose_2_pose(target_pose.pose)#current_objects[max_z_index].results[0].pose.pose)
                  
                # box_size  
                bbox1=current_objects[max_z_index].bbox
                box_size=(bbox1.size.x,bbox1.size.y,box_thickness_z)
                # box_size =(0.2, 0.2, box_thickness_z) 
                box_pose = geometry_msgs.msg.PoseStamped()
                box_pose.header.frame_id = self.robot_name
                box_pose.pose=bbox1.center#current_objects[max_z_index].results[0].pose.pose
                # box_pose.pose.orientation.w = 1.0
                # box_pose.pose.position.x = x
                # box_pose.pose.position.y = y
                # box_pose.pose.position.z = z  
                box_name = "picking_target" 
                self.scene.add_box(box_name, box_pose, size=box_size) 
                
                acm = self.scene.allowedCollisionMatrixDict
                acm = self.scene.set_entry(acm, [self.robot_name+'/solomon_tool_link', box_name], True)
                acm = self.scene.set_entry(acm, [self.robot_name+'/obj_link0', box_name], True) 
                self.scene.allowedCollisionMatrixDict = acm 
                object_available=True
                

                #dipslay Picking obj
                self.markers.publishAxis(target_pose, 0.2, 0.02, 500.0)
                self.markers.publishText(target_pose ,self.robot_name+" pick",'yellow', Vector3Geometry(0.1,0.1,0.1), 500.0)
                print("object available!")

                #capture depth image at detect 
                depth_buff= rospy.wait_for_message('/camera/aligned_depth_to_color/image_raw', Image,timeout=10)  
                self.depth_at_detect = self.bridge.imgmsg_to_cv2(depth_buff, "32FC1")
                # color_buff= rospy.wait_for_message('/camera/color/image_raw', Image,timeout=10)  
                # color_after_pick = self.bridge.imgmsg_to_cv2(color_buff, "bgr8") 
                
                # cv2.imwrite("color_after_pick.bmp",color_after_pick)
                print("Captured depth_at_detect")
                 
            if(object_available is False):
                print("object NOT available!")
                rospy.sleep(1)
           
            
        #display detected_targets
        self.markers.deleteAllMarkers()
        self.display_path(self.detected_targets,'obj ',show_path=False)
        #print("wait for key to exit")
        
        # k=cv2.waitKey(33) 
        # exit()
        return approach_pose,target_pose,leave_pose,box_pose,box_size 
    
    def get_two_targets(self):
        approach_pose = PoseStamped() 
        target_pose = PoseStamped() 
        leave_pose  = PoseStamped()  
    
        #bin center
        bx=self.bin_right_center[0]
        by=self.bin_right_center[1]
        bz=self.bin_right_center[2]
        # global current_objects 
       
        object_available=False
        box_size=None 
       
        target1=None
        target2=None
        while (object_available is False):
            # call service
            print("call service...........................")
            res=None
            res = self.detect_proxy()
            current_objects = res.result.detections
            self.detected_targets=[]
    
            max_z_index=-1
            max_z_value=-1000000
            
            for i in range(len(current_objects)): 
                x=current_objects[i].results[0].pose.pose.position.x #+0.02
                y=current_objects[i].results[0].pose.pose.position.y 
                z=current_objects[i].results[0].pose.pose.position.z 

                print(i," pose=",x,y,z)
                if ((bx-x)*(bx-x) <0.35*0.35) and ((by-y)*(by-y) <0.25*0.25)  and  z>(bz) and  z<0.2:
                    self.detected_targets.append(geometry_msgs_Pose_2_pose(current_objects[i].results[0].pose.pose))

                    #if (z>max_z_value): #get highest z object 
                    #pick closest object
                    if (-abs(self.world2robot.Pos()[0]-x)>max_z_value):
                        max_z_index=i
                        max_z_value=-abs(self.world2robot.Pos()[0]-x)

                        #target1
                        target1=geometry_msgs_Pose_2_pose(current_objects[i].results[0].pose.pose)
    
            #find available picking target
            if(max_z_index>-1):
                #add another pose target2
                max_dist=-1000000
                for i,target in enumerate(self.detected_targets): 
                    if distance(target1.Pos(),target.Pos())>max_dist:
                        max_dist=distance(target1.Pos(),target.Pos())
                        target2=target

            
            #dipslay Picking obj
            self.markers.publishAxis(target1, 0.2, 0.02, 500.0)
            self.markers.publishText(target1 ,self.robot_name+" pick1",'yellow', Vector3Geometry(0.1,0.1,0.1), 500.0)
            self.markers.publishAxis(target2, 0.2, 0.02, 500.0)
            self.markers.publishText(target2 ,self.robot_name+" pick2",'yellow', Vector3Geometry(0.1,0.1,0.1), 500.0)
            print("object available!")

            object_available=True

            print("target1=",target1)
            print("target2=",target2)
        return target1,target2
    
    def planning_a_joint_goal(self,goal_joint): 
    
        # The go command can be called with joint values, poses, or without any
        # parameters if you have already set the pose or joint target for the group 
        current_pose=self.move_group.get_current_pose().pose
      
        # We can get the joint values from the group and adjust some of the values:
        current_joint = self.move_group.get_current_joint_values()
        count_retry=0
        #print('=====current_joint=',current_joint,dir(current_joint))
        #print('=======goal_joint=',goal_joint)

        if len(current_joint) ==0:
            return
        while (different(current_joint,goal_joint)>0.004): 
            # The go command can be called with joint values, poses, or without any
            # parameters if you have already set the pose or joint target for the group 
            current_joint[0]=goal_joint[0]
            current_joint[1]=goal_joint[1]
            current_joint[2]=goal_joint[2]
            current_joint[3]=goal_joint[3]
            current_joint[4]=goal_joint[4]
            current_joint[5]=goal_joint[5]
            self.move_group.set_joint_value_target(current_joint); 
            
            traj = self.move_group.plan() 
            if (traj[0]):
                print("PLAN SUCESS.......goal_joint=",goal_joint) 
                print(traj[1].joint_trajectory.points) 

            else:
                print("PLAN FAIL.......goal_joint=",goal_joint)   
            self.move_group.go(wait=True)#current_joint, 
            print("planning a goal...")
    
            # Calling ``stop()`` ensures that there is no residual movement
            self.move_group.stop()
    
            #plan = self.move_group.go(wait=True)  

            current_joint = self.move_group.get_current_joint_values()   
            count_retry+=1
    
            if (count_retry%2 ==0):
                #self.clear_octomap()
                print("Reset Octomap...")
                rospy.sleep(.1)
            rospy.loginfo("count_retry=%i",count_retry)  
    
    def MoveJ(self,goal_joint):
        Logger.loginfo("inside robot movej: jointnames= %s" %goal_joint)  
        self.planning_a_joint_goal(goal_joint)
    
    def MoveJ_thread(self, goal_joint):
        x = threading.Thread(target=self.MoveJ, args=(goal_joint,))
        x.start()
        return x
    
    def MoveL(self, target):  
        #target is RoboDK pose 
        self.update_display_path(target)
        self.planning_a_goal_pose(pose_2_geometry_msgs_Pose(target)) 

    def display_path(self,target_list=None,name_str='',show_path=True): 
        if (target_list is None):
            if (self.planned_path is None):
                return
            #print("Display length num=",len(self.planned_path.joint_trajectory.points))
            target_list = self.joint_path_2_pose_path(self.planned_path.joint_trajectory.points)

        path=[]
        for i,target in enumerate(target_list): 
            target_geometry_pose=pose_2_geometry_msgs_Pose(target) 

            self.markers.publishAxis(target_geometry_pose, 0.1, 0.02, 500.0)
            self.markers.publishText(pose_2_geometry_msgs_Pose(target*transl(0,0,-0.05)) ,name_str+str(i),'white', Vector3Geometry(0.1,0.1,0.1), 500.0)
            
            path.append(PointGeometry(target.Pos()[0],target.Pos()[1],target.Pos()[2])) 
        
        if show_path:
            self.markers.publishPath(path, 'yellow', 0.01, 500.0) # path, color, width, lifetime 
    
    def update_display_path(self,target):    
        path=[]
        if (len(self.recent_path)>0):
            target1=self.recent_path[len(self.recent_path)-1]
            path.append(PointGeometry(target1.Pos()[0],target1.Pos()[1],target1.Pos()[2])) 
        
        self.recent_path.append(target)
        
        target_geometry_pose=pose_2_geometry_msgs_Pose(target) 
        self.markers.publishAxis(target_geometry_pose, 0.1, 0.02, 500.0)
        self.markers.publishText(pose_2_geometry_msgs_Pose(target*transl(0,0,-0.05)) ,str(len(self.recent_path)-1),'white', Vector3Geometry(0.1,0.1,0.1), 500.0)
        path.append(PointGeometry(target.Pos()[0],target.Pos()[1],target.Pos()[2])) 

        self.markers.publishPath(path, 'white', 0.01, 500.0) # path, color, width, lifetime 

    def MoveL_thread(self, target):
        x = threading.Thread(target=self.MoveL, args=(target,))
        x.start()

    def planning_a_goal_pose(self,goal_pose):     
        # curreent geometry pose in robot coordinate
        current_pose_world=self.move_group.get_current_pose().pose
        current_pose= current_pose_world# pose_2_geometry_msgs_Pose(self.world2robot.__mul__(geometry_msgs_Pose_2_pose(current_pose_world)))
         
        print("goalpose=",goal_pose)
        count_retry=0
        while (different_pose(current_pose,goal_pose)>0.004):  
            diff_pose=different_pose(current_pose,goal_pose)
            self.move_group.set_pose_target(goal_pose); 
            traj = self.move_group.plan() 
            if (traj[0]):
                print("PLAN SUCESS.......goal_pose=",goal_pose) 
                self.planned_path=traj[1].joint_trajectory 
                self.display_path(self.joint_path_2_pose_path(self.planned_path.points))
 

            self.move_group.go(wait=True)  

            self.move_group.stop()
            # It is always good to clear your targets after planning with poses.
            # Note: there is no equivalent function for clear_joint_value_targets()
            self.move_group.clear_pose_targets()
            
            current_pose=self.current_robot_pose()
         
            count_retry+=1
    
            if (count_retry%2 ==0):
                self.clear_octomap()
                print("Reset Octomap...")
                rospy.sleep(.1)
            print("count_retry=",count_retry, "dif=",diff_pose, "goal pose=\n",goal_pose)  
            print("current_pose=\n",current_pose)
    
    def get_planning_a_target(self,target):    
        goal_pose=pose_2_geometry_msgs_Pose(target)  
        print("planning to goalpose=",goal_pose) 
        success=False
        count_retry=0
        self.move_group.set_pose_target(goal_pose); 
        while (success is False): #while
            count_retry+=1
            traj = self.move_group.plan() 
            success=traj[0]
            if (success):
                print("PLAN SUCESS.......goal_pose=",goal_pose) 
                self.planned_path=traj[1]#.joint_trajectory 
                self.display_path()
            else:
                print("PLAN FAIL Num=",count_retry,".......goal_pose=",goal_pose)  

    def get_path_joint_2_target(self, start_joint, target, display=False):
        goal_pose=pose_2_geometry_msgs_Pose(target)
        print("planning to goalpose=",goal_pose) 
        success=False 

        # TEST: make same pose as current
        curr_pose = self.move_group.get_current_pose()
        goal_pose.orientation = curr_pose.pose.orientation
        #
        header = std_msgs.msg.Header()
        header.stamp = rospy.Time.now()
        header.frame_id = self.move_group.get_pose_reference_frame()
        rs = RobotState()
        rs.joint_state.header = header
        rs.joint_state.name = self.joint_names
        rs.joint_state.position = start_joint

        self.move_group.set_start_state(rs)
        self.move_group.set_pose_target(goal_pose)
    
        traj = self.move_group.plan() 
        success=traj[0]
        if (success):
            # print("PLAN SUCESS.......goal_pose=",goal_pose)
            print("PLAN SUCESS.......")
            self.planned_path=traj[1]
            if display:
                self.display_path()
            return self.planned_path
        else:
            # print("PLAN FAIL.......goal_pose=",goal_pose)
            print("PLAN FAIL.......")
            return None
    
    def get_path_joint_2_target_cartesian(self, start_joint, target, display=False): 
        waypoints =[]
        if type(target) is list:
            goal_pose = pose_2_geometry_msgs_Pose(target[-1])
            #TEST: make same pose as current
            curr_pose = self.move_group.get_current_pose()
            goal_pose.orientation = curr_pose.pose.orientation
            #
            waypoints = [copy.deepcopy(pose_2_geometry_msgs_Pose(wp)) for wp in target]
        else:
            goal_pose = pose_2_geometry_msgs_Pose(target)
            #TEST: make same pose as current
            curr_pose = self.move_group.get_current_pose()
            goal_pose.orientation = curr_pose.pose.orientation
            #
            waypoints.append(copy.deepcopy(goal_pose))
            print("cartesian planning to goalpose=",goal_pose)

        header = std_msgs.msg.Header()
        header.stamp = rospy.Time.now()
        header.frame_id = self.move_group.get_pose_reference_frame()
        rs = RobotState()
        rs.joint_state.header = header
        rs.joint_state.name = self.joint_names
        rs.joint_state.position = start_joint

        self.move_group.set_start_state(rs)

        (plan, fraction) = self.move_group.compute_cartesian_path(
                                        waypoints,   # waypoints to follow
                                        0.02,        # eef_step
                                        2.0,         # jump_threshold
                                        False)       # avoid_collisions
        if (fraction > 0.95):
            # print("PLAN SUCESS.......cartesian goal_pose=",goal_pose) 
            print("PLAN SUCESS.......cartesian")
            self.planned_path=plan
            if display:
                self.display_path()
            return self.planned_path
        else:
            # print("PLAN FAIL.......cartesian goal_pose=",goal_pose)
            print("PLAN FAIL.......cartesian")
            return None

    def execute_planned_trajectory(self,joint_path,_wait=True):
        if (joint_path is None):
            return
        # rospy.sleep(0.1)
        # print(joint_path)
        self.move_group.execute(joint_path, wait = _wait)#.go(wait=_wait)#
        # self.move_group.go(wait=_wait)#
        print("done execute.")
        # rospy.sleep(5)
        self.move_group.stop()
        # It is always good to clear your targets after planning with poses.
        # Note: there is no equivalent function for clear_joint_value_targets()
        self.move_group.clear_pose_targets()

    def execute_planned_trajectory_thread(self,joint_path):
        x = threading.Thread(target=self.execute_planned_trajectory, args=(joint_path,))
        x.start()

    def set_path_constraint(self,rx=pi/2,ry=pi/2,rz=2*pi): 
        #set constraint
        ocm= OrientationConstraint() 
        ocm.link_name = self.tcp0_name
        ocm.header.frame_id = "world" 
        ocm.orientation=current_pose_world.orientation
        ocm.absolute_x_axis_tolerance = rx
        ocm.absolute_y_axis_tolerance = ry
        ocm.absolute_z_axis_tolerance = rz
        ocm.weight = 1.0
    
        test_constraints=Constraints()
        test_constraints.orientation_constraints.append(ocm)
        self.move_group.set_path_constraints(test_constraints)
         
    def solomon_pack_test(self):
        preset_cuboids =[]# [[0,0,0,50,50,60],[50,0,0,50,50,150],[200,200,0,50,50,300]]
        pack_cuiboid=[0,0,0,40,50,10]
        bin_size = (300,300,450) 
    
        #generate grid
        grid_size_w=28
        grid_size_h=28
    
        step_w=bin_size[0]/grid_size_w
        step_h=bin_size[1]/grid_size_h
    
        for i in range(grid_size_w):
            for j in range(grid_size_h):
                if random.uniform(0,1)>0.5:
                    preset_cuboids.append([step_w*i,step_h*j,0,step_w,step_h,random.uniform(bin_size[2]/5, bin_size[2]*5/6) ])
        pack3D=SolPalletization(_bin_size=bin_size)
        print("Bin Size (W,H,D)=",pack3D.bin_size)
        #print("free rect number=",len(pack3D.packer2D._max_rects))
        start= time.time()
        success,pack_pose,pack_cuboid3D=pack3D.pack(preset_cuboids,pack_cuiboid,box_pose=np.identity(4),pick_pose=np.identity(4), level_num=20,display2D=True)
        
        end = time.time()
        print("Pack time=", end - start)
    
    def get_box_size(self): 
        if (self.depth_at_detect is not None):
            depth_buff= rospy.wait_for_message('/camera/aligned_depth_to_color/image_raw', Image,timeout=10)  
            self.depth_after_pick = self.bridge.imgmsg_to_cv2(depth_buff, "32FC1")
    
            color_buff= rospy.wait_for_message('/camera/color/image_raw', Image,timeout=10)  
            color_after_pick = self.bridge.imgmsg_to_cv2(color_buff, "bgr8")
    
            print('image shape: ', color_after_pick.shape, type(color_after_pick))
            print('depth shape: ', self.depth_after_pick.shape, type(self.depth_after_pick))
             
    
            #detect box 
            boxDetect = BoxLocalization(self.depth_at_detect, self.depth_after_pick, self.V2R,self.color_camera_info,self.pick_pose,select_ROI=self.roi_right)
            
            # compute the rotated box coordinate only
            return boxDetect.compute_Rotated_Box(boxDetect.img_subtract_uint8, boxDetect.Detected_Box_Info) 
        else:
            return None,None,None,None,None
    
    def pack_a_cube(self,_pack_cuiboid=[0,0,0,40,50,10],box_pose=np.identity(4),pick_pose=np.identity(4), level_num=20,display2D=True):
        
        #start packing
        start= time.time()
        preset_cuboids =[]# [[0,0,0,50,50,60],[50,0,0,50,50,150],[200,200,0,50,50,300]] 
        pack_cuiboid=_pack_cuiboid
        bin_size = (0.40,0.500,0.30)#(0.320,0.450,0.230)   #bin in 3F
    
        #bin_pose in Robot Frame
        bin_pose=np.identity(4)
        bin_pose[0,3]=-0.409
        bin_pose[1,3]=-0.907
        bin_pose[2,3]=-0.108
        #convert to World Frame 
        bin_pose_w=np.matmul(np.linalg.inv( pose_2_array(self.world2robot) ),bin_pose)
        
        pack3D=SolPalletization(_bin_size=bin_size,_bin_pose=bin_pose)
        print("Bin Size (W,H,D)=",pack3D.bin_size)
        print("Bin POSE=",bin_pose)
        print("Bin POSE WORLD=",bin_pose_w)
    
        bin_pose_w_inv=np.linalg.inv(bin_pose_w)
        '''
        #initialize preset cuboids
        #Octomap Web request
        pub = rospy.Publisher('/web_octo_update', Empty_msg, queue_size=10)
        rospy.sleep(1) 
        pub.publish(Empty_msg())
        #Get octomap
        self.marker_array = rospy.wait_for_message("free_cells_vis_array", MarkerArray,  timeout=10)  
        ''' 
        print("MARKER NUMBER=",dir(self.marker_array.markers))    
        print("MARKER array len=",len(self.marker_array.markers)) 
        for i,marker in enumerate(self.marker_array.markers):
            if(len(marker.points)>0):
                print("tree level=",i,"frame=",marker.header.frame_id,"cube num=",len(marker.points))
                print("scale\n=",marker.scale,"\norientation=\n",marker.pose.orientation)
                for j,pos in enumerate(marker.points):
                    # multiple V2R
                    XYZ=np.inner(bin_pose_w_inv,[pos.x,pos.y,pos.z,1]) 
                    if (XYZ[0]>0) and (XYZ[0]<bin_size[0]) and (XYZ[1]>0) and (XYZ[1]<bin_size[1]) and (XYZ[2]>0) and (XYZ[2]<bin_size[2]):
                        preset_cuboids.append([XYZ[0]-marker.scale.x/2,XYZ[1]-marker.scale.y/2,XYZ[2]-marker.scale.z/2,marker.scale.x,marker.scale.y,marker.scale.z])
                    #if (j%100==0):
                    #    print(j,pos,XYZ)
        
        end = time.time()
        print("Octomap reading time=", end - start)
        success,pack_pose,pack_cuboid3D= pack3D.pack(preset_cuboids,pack_cuiboid,box_pose=box_pose,pick_pose=pick_pose, level_num=level_num,display2D=display2D)
        #DISPLAY by ROS scene 
        if False:#success:
            print("SUCCESS! \npack_pose=\n",pack_pose)
            print("pack_cuboid3D=\n",pack_cuboid3D)
            file1 = open("packing.scene","w")  
            
            # \n is placed to indicate EOL (End of Line) 
            file1.write("Scene Objects for ROS \n") 
            
            file1.writelines("BIN\n\n")  
            file1.writelines("1\nbox\n")    
            file1.writelines(str(bin_size[0])+" "+str(bin_size[1])+" "+str(bin_size[2])+"\n")
            file1.writelines(str(bin_size[0]/2)+" "+str(bin_size[1]/2)+" "+str(bin_size[2]/2)+"\n")
            file1.writelines("0 0 0 1"+"\n")
            file1.writelines("0 0 0 0"+"\n")
            
            file1.writelines("PACKED_CUIBOID\n\n")  
            file1.writelines("1\nbox\n")    
            file1.writelines(str(pack_cuboid3D[3])+" "+str(pack_cuboid3D[4])+" "+str(pack_cuboid3D[5])+"\n")
            file1.writelines(str(pack_cuboid3D[0]+pack_cuboid3D[3]/2)+" "+str(pack_cuboid3D[1]+pack_cuboid3D[4]/2)+" "+str(pack_cuboid3D[2]+pack_cuboid3D[5]/2)+"\n")
            file1.writelines("0 0 0 1"+"\n")
            file1.writelines("0 0 0 0"+"\n")
              
            
            for i,cuboid in enumerate(preset_cuboids):
                file1.writelines("cuboid "+str(i)+"\n\n")  
                file1.writelines("1\nbox\n")    
                file1.writelines(str(cuboid[3])+" "+str(cuboid[4])+" "+str(cuboid[5])+"\n")
                file1.writelines(str(cuboid[0]+cuboid[3]/2)+" "+str(cuboid[1]+cuboid[4]/2)+" "+str(cuboid[2]+cuboid[5]/2)+"\n")
                file1.writelines("0 0 0 1"+"\n")
                file1.writelines("0 0 0 0"+"\n")
            file1.close() #to change file access modes 
    
        return success,pack_pose,pack_cuboid3D

    def run(self): 
        goal_A = [i/180.0*pi for i in self.home_joint] 
         
        #detect box 
        #boxDetect = BoxLocalization(self.depth_at_detect, self.depth_after_pick, self.V2R,self.color_camera_info,self.pick_pose,select_ROI=self.roi_right)
            
        
        count=0   
        while count >-1 and not rospy.is_shutdown():  
            
            self.planning_a_joint_goal(goal_A)  
           
            #capture depth image at detect
            #box_pose,W,H,D,vis= self.get_box_size()
            box_pose=None
            if box_pose is not None: 
                #DRAW CORRECT BOX
                #cv2.imshow("Detected Box", vis)  
                # box_size  
                box_size =(W,H,D) 
                box_pose_c = geometry_msgs.msg.PoseStamped()
                box_pose_c.header.frame_id = self.robot_name
                box_pose_c.pose=pose_2_geometry_msgs_Pose(box_pose.__mul__(transl(W/2,H/2,D/2))) #pose_2_geometry_msgs_Pose(box_pose)#array_2_pose(
                box_name = "correct_box" 
                self.scene.add_box(box_name, box_pose_c, size=box_size) 
                 
                #update attached box
                box_pose_tcp0=(self.pick_pose.inv()).__mul__(box_pose)
                box_pose_measured = geometry_msgs.msg.PoseStamped()
                box_pose_measured.header.frame_id = self.tcp0_name
                box_pose_measured.pose=pose_2_geometry_msgs_Pose(box_pose_tcp0.__mul__(transl(W/2,H/2,D/2))) 
    
                self.scene.attach_box(self.eef_link, "attached_target", pose=box_pose_measured, size=(W,H,D), touch_links=self.eef_link)
                acm = self.scene.allowedCollisionMatrixDict
                acm = self.scene.set_entry(acm, ['attached_target', 'picking_target'], True)
                acm = self.scene.set_entry(acm, [self.robot_name+'/solomon_tool_link', 'attached_target'], True)
                acm = self.scene.set_entry(acm, [self.robot_name+'/obj_link0', 'attached_target'], True)
    
                self.scene.allowedCollisionMatrixDict = acm 
    
                print("==UPDATE===========box_pose_measured=",box_pose_measured)
                print("---------PICK POSE=\n",self.pick_pose)
                print("---------BOX POSE=\n",box_pose)
                
                
                #ARRIVE PRETARGET==>GET OCTOMAP FOR PACKING
                success,pack_pose_array,pack_cuboid3D=self.pack_a_cube(_pack_cuiboid=[0,0,0,W,H,D],box_pose=pose_2_array(box_pose),pick_pose=pose_2_array(self.pick_pose), level_num=20,display2D=True)
                if (success):
                    #format SAFETY 2.8cm
                    safety_z_octomap=0.028
                    pack_pose=array_2_pose(pack_pose_array).__mul__(transl(0,0,-safety_z_octomap))#RoboDK 
                    
                    pack_pose_approach=pack_pose.__mul__(transl(0,0,-0.3))
                    print("--------------pack_pose=",pack_pose)
                    print("--------------pack_pose_approach=",pack_pose_approach)

                     # box_size  
                    box_size =(W, H, D) 
                    box_pose = geometry_msgs.msg.PoseStamped()
                    box_pose.header.frame_id = self.robot_name
                    box_pose.pose= pose_2_geometry_msgs_Pose(pack_pose.__mul__(box_pose_tcp0.__mul__(transl(W/2,H/2,D/2))))


                    box_name = "picking_target" 
                    self.scene.add_box(box_name, box_pose, size=box_size) 
                    
                    acm = self.scene.allowedCollisionMatrixDict
                    acm = self.scene.set_entry(acm, [self.robot_name+'/solomon_tool_link', box_name], True)
                    acm = self.scene.set_entry(acm, [self.robot_name+'/obj_link0', box_name], True) 
                    self.scene.allowedCollisionMatrixDict = acm 

                    self.planning_a_goal_pose(pose_2_geometry_msgs_Pose(pack_pose_approach))
 
                    rospy.sleep(1)

                    self.cartesian_plan(pose_2_geometry_msgs_Pose(pack_pose))

                    #Place object+6
                    self.scene.remove_attached_object(self.eef_link, "attached_target")
                    self.scene.remove_world_object("attached_target")
                    self.scene.remove_world_object("picking_target")   
                    self.scene.remove_world_object("correct_box") 
                    
                    #Close Suction 
                    self.io.digital(self.io_id, 0)

                    self.planning_a_goal_pose(pose_2_geometry_msgs_Pose(pack_pose_approach))

                    print("============================================PACK ACTION+++++++++",pack_pose) 
                 
            else:
                #Close Suction 
                self.io.digital(self.io_id, 0) 
                #Place object+6
                self.scene.remove_attached_object(self.eef_link, "attached_target")
                self.scene.remove_world_object("attached_target")
                self.scene.remove_world_object("picking_target")   
                self.scene.remove_world_object("correct_box") 
             
            #approach_pose,target_pose,leave_pose: are PoseStamp()
            approach_pose,target_pose,leave_pose,box_pose_guess,size= self.get_targeting_object()  
             
            #print("dz_approach=",dz_approach,"dz_leave=",dz_leave)
            print("approach_pose=",approach_pose)
            print("target_pose=",target_pose)
            print("leave_pose=",leave_pose)

            #planning to pick point
            self.planning_a_goal_pose(approach_pose.pose)
            self.markers.publishAxis(approach_pose, 0.1, 0.02, 5.0)
           
            #approach 
            self.cartesian_plan(target_pose.pose)#cartesian_plan
            self.markers.publishAxis(target_pose.pose, 0.12, 0.02, 5.0)

            #get orientation: remain the orientation
            self.pick_pose=geometry_msgs_Pose_2_pose(self.current_robot_pose())  

            #Open Suction 
            self.io.digital(self.io_id,1)

            #get Octomap in another bin
            #initialize preset cuboids
            #Octomap Web request
            pub = rospy.Publisher('/web_octo_update', Empty_msg, queue_size=10)
            rospy.sleep(1) 
            pub.publish(Empty_msg())
            #Get octomap
            #self.marker_array = rospy.wait_for_message("/free_cells_vis_array", MarkerArray,  timeout=10)  
    
            #Pick object         
            box_pose_tcp0=(self.pick_pose.inv()).__mul__(geometry_msgs_Pose_2_pose(box_pose_guess.pose))        
            box_pose_guess = geometry_msgs.msg.PoseStamped()
            box_pose_guess.header.frame_id = self.tcp0_name
            box_pose_guess.pose=pose_2_geometry_msgs_Pose(box_pose_tcp0)#.__mul__(transl(W/2,H/2,D/2))) 
            # box_pose_guess.pose.orientation.w = 1.0
            # box_pose_guess.pose.position.x = 0
            # box_pose_guess.pose.position.y = 0
            # box_pose_guess.pose.position.z = (size[2]-0.08)/2 
  
            self.scene.attach_box(self.eef_link, "attached_target", pose=box_pose_guess, size=(size[0],size[1],size[2]), touch_links=self.eef_link)
            acm = self.scene.allowedCollisionMatrixDict
            acm = self.scene.set_entry(acm, ['attached_target', 'picking_target'], True)
            acm = self.scene.set_entry(acm, [self.robot_name+'/solomon_tool_link', 'attached_target'], True)
            acm = self.scene.set_entry(acm, [self.robot_name+'/obj_link0', 'attached_target'], True)
            self.scene.allowedCollisionMatrixDict = acm 
             
            #retreat
            self.cartesian_plan(leave_pose.pose) 
            self.markers.publishAxis(leave_pose.pose, 0.15, 0.02, 5.0)
    
            count+=1
            rospy.loginfo('loop count= %i',count)
    
    def run_thread(self):
        x = threading.Thread(target=self.run)
        x.start()
    
    def test_hexagon(self,N=6,radius=0.2): 
        pose1=geometry_msgs_Pose_2_pose(self.move_group.get_current_pose().pose)
        for i in range(N+1): 
            ang = i*2*pi/N #angle: 0, 60, 120, ... 
            posei = pose1*rotz(ang)*transl(radius,0,0)*rotz(-ang) 
            self.MoveL(posei)

    def call_compute_fk(self, joint_pose, links):
        
        #print('call_compute_fk starts...')
        rospy.wait_for_service(self.robot_name+'/compute_fk')

        try:
            compute_fk_srv = rospy.ServiceProxy(self.robot_name+'/compute_fk', GetPositionFK)
            header = std_msgs.msg.Header()
            header.stamp = rospy.Time.now()
            header.frame_id = self.move_group.get_pose_reference_frame()

            rs = RobotState()
            rs.joint_state.header = header
            rs.joint_state.name = self.joint_names
            rs.joint_state.position = joint_pose

            res = compute_fk_srv(header, links, rs) 
            
            #print("FK==>",self.joint_names)
            #print("compute_fk_srv==>",res)
            return res.pose_stamped 

        except rospy.ServiceException as e:
            print("Service call failed: %s"%e)
    
    def joint_path_2_pose_path(self,traj1,max_num=5):
        pose_path=[]

        for joint1 in traj1:
            # print(joint1.positions)
            res=self.call_compute_fk(joint1.positions,[self.tcp0_name])
            pose_path.append(geometry_msgs_Pose_2_pose(res[0].pose))

        return pose_path

    def add_joint_path_2_scene(self,link_names,link_dims,_scene=None):
        scene=None
        if (_scene is not None):
            scene=_scene
        else:
            scene=self.scene
        self.planned_path_cube_num=0 
        if self.planned_path is None:
            return

        for joint1 in self.planned_path.joint_trajectory.points:
            res=self.call_compute_fk(joint1.positions,link_names)
            for i,link_name in enumerate(link_names[0:-1]):
                box_pose = geometry_msgs.msg.PoseStamped()
                box_pose.header.frame_id = "world"

                vec_x = res[i+1].pose.position.x - res[i].pose.position.x
                vec_y = res[i+1].pose.position.y - res[i].pose.position.y
                vec_z = res[i+1].pose.position.z - res[i].pose.position.z
                vec = np.array([vec_x, vec_y, vec_z])
                length = np.linalg.norm(vec) #!
                world_z = [0, 0, 1]
                frame_z = vec/length # unit vector

                frame_y = np.cross(frame_z, world_z)
                if np.linalg.norm(frame_y) > sys.float_info.epsilon:
                    frame_x = np.cross(frame_y, frame_z)
                else:
                    world_x = [1, 0, 0]
                    frame_y = np.cross(frame_z, world_x)
                    frame_x = np.cross(frame_y, frame_z)

                # set to unit vector
                frame_x = frame_x/np.linalg.norm(frame_x)
                frame_y = frame_y/np.linalg.norm(frame_y)

                # set cylinder pose
                pose_mat = np.identity(4)
                pose_mat[0:-1, 0] = frame_x
                pose_mat[0:-1, 1] = frame_y
                pose_mat[0:-1, 2] = frame_z
                pose_mat[0:-1, 3] = [res[i].pose.position.x + vec_x/2,
                                     res[i].pose.position.y + vec_y/2,
                                     res[i].pose.position.z + vec_z/2]

                box_pose.pose=pose_2_geometry_msgs_Pose(pose_mat)
                scene.add_object(self.robot_name+"_"+str(self.planned_path_cube_num),
                                 box_pose,
                                 SolidPrimitive.CYLINDER,
                                 link_dims[i])
                # scene.add_object(self.robot_name+"_"+str(self.planned_path_cube_num),
                #                  box_pose,
                #                  SolidPrimitive.CYLINDER,
                #                  (length, link_dims[i][1]))#!
                self.planned_path_cube_num+=1
                print("link name:"+link_name)

    def add_robot_bounding(self,link_names,link_offsets,link_dims,_scene=None ):
        scene=None
        if (_scene is not None):
            scene=_scene
        else:
            scene=self.scene
        robot_name=None
        
        self.planned_path_cube_num=0
        joint1 = self.move_group.get_current_joint_values() 
        res=self.call_compute_fk(joint1,link_names)
        for i,link_name in enumerate(link_names): 
            rot_mat=rotz(0) 
            if i==1 or i==3:
                rot_mat=rotx(-pi/2) 

            box_pose = geometry_msgs.msg.PoseStamped()
            box_pose.header.frame_id = "/world"
            box_pose.pose=pose_2_geometry_msgs_Pose(  geometry_msgs_Pose_2_pose(res[i].pose)*rot_mat*transl(link_offsets[i][0],link_offsets[i][1],link_offsets[i][2])  )

            #self.scene.add_box(self.robot_name+"_"+str(self.planned_path_cube_num), box_pose, size=link_dims[i])    
            scene.add_cylinder(self.robot_name+"_"+str(self.planned_path_cube_num), box_pose,link_dims[i][2], link_dims[i][1])    
            
            self.planned_path_cube_num+=1
    
    def clean_planned_path_cubes(self,_robot_name=None):
        robot_name=None
        if (_robot_name is not None):
            robot_name=_robot_name
        else:
            robot_name=self.robot_name

        max_obj_num=len(self.scene.get_objects())
        for i in range(max_obj_num):
            self.scene.remove_world_object(robot_name+"_"+str(i))

    def display_rviz_traj(self, traj, robot_name=None):
        header = std_msgs.msg.Header()
        header.stamp = rospy.Time.now()
        # header.frame_id = self.left_arm.move_group.get_pose_reference_frame()
        start_rs = RobotState()
        start_rs.joint_state.header = header
        start_rs.joint_state.name = traj.joint_trajectory.joint_names
        start_rs.joint_state.position = traj.joint_trajectory.points[0].positions
        display_traj = DisplayTrajectory(robot_name, [traj], start_rs)
        self.pub_traj.publish(display_traj)

class SolSceneCollisionObjectManager():
    def __init__(self):
        # for save each robot scene info
        self.robot_primitives = dict() # primitives
        self.robot_tool_primitives = dict() # primitives
        self.robot_ps_world = dict() # planning scene world
        self.robot_scene_is_diff = dict() # check public scene is same as robot scene or not
        # public scene: set all robot scene collision objects there
        self.public_scene = PlanningScene()
        # todo: some public scene init there
        # self.publib_scene_is_diff = bool()
        
    def add_robot_primitives(self, robot_name, type, size):
        primitives = []
        for i in range(len(type)):
            sp = SolidPrimitive(type = type[i], dimensions = list(size[i]))
            primitives.append(sp)

        self.robot_primitives[robot_name] = primitives
        self.robot_ps_world[robot_name] = PlanningSceneWorld()
        self.robot_scene_is_diff[robot_name] = True #True

    def add_robot_tool_primitives(self, robot_name, type, size):
        primitives = []
        sp = SolidPrimitive(type = type, dimensions = list(size))
        primitives.append(sp)
        self.robot_tool_primitives[robot_name] = primitives

    # this param poses is a list of robot primitives pose
    def append_robot_collision_object(self, robot_name, poses):
        if not self.robot_ps_world.get(robot_name):
            raise Exception("robot name [{}] is not exist in dict".format(robot_name))
        if not isinstance(poses, list):
            raise Exception("input poses must be a list")

        co = CollisionObject()
        co.operation = CollisionObject.ADD
        co.id = robot_name + '_' + str(len(self.robot_ps_world[robot_name].collision_objects))
        co.header = poses[0].header
        co.primitives = self.robot_primitives[robot_name]
        co.primitive_poses = [p.pose for p in poses]

        self.robot_ps_world[robot_name].collision_objects.append(co)

    def append_robot_tool(self, robot_name, pose):
        co = CollisionObject()
        co.operation = CollisionObject.ADD
        co.id = robot_name + '_' + str(len(self.robot_ps_world[robot_name].collision_objects))
        co.header = pose.header
        co.primitives = self.robot_tool_primitives[robot_name]
        co.primitive_poses = [pose.pose]

        self.robot_ps_world[robot_name].collision_objects.append(co)

    def del_robot_collision_object(self, robot_name, robot_scene):
        obj_names = robot_scene.get_known_object_names()
        all_robot_co_names = [name for name in obj_names if re.search('robot', name)]
        other_robot_co_names = [name for name in all_robot_co_names if not re.search(robot_name, name)]

        ps = PlanningScene()
        for co_name in other_robot_co_names:
            co = CollisionObject()
            co.operation = CollisionObject.REMOVE
            co.id = co_name
            ps.world.collision_objects.append(co)
        robot_scene.set_scene(ps)

    def update_robot_public_scene(self, robot_name, poses_list, tool_pose_list = None):
        # clear old poses
        self.robot_ps_world[robot_name].collision_objects = []
        self.public_scene.world.collision_objects = []

        # append poses
        for poses in poses_list:
            self.append_robot_collision_object(robot_name, poses)

        if tool_pose_list is not None:
            for pose in tool_pose_list:
                self.append_robot_tool(robot_name, pose)

        # update public scene
        for psw in self.robot_ps_world.values():
            self.public_scene.world.collision_objects += psw.collision_objects

        for key in self.robot_scene_is_diff:
            self.robot_scene_is_diff[key] = True

    def set_public_scene_to_robot(self, robot_name, robot_scene, without_self = False):
        if not without_self:
            robot_scene.set_scene(self.public_scene)
            self.robot_scene_is_diff[robot_name] = False
        else:
            self.del_robot_collision_object(robot_name, robot_scene)
            ps = PlanningScene()
            # [self.robot_ps_world[key] for key in self.robot_ps_world if key != robot_name]
            for key in self.robot_ps_world:
                if key != robot_name:
                    psw = self.robot_ps_world[key]
                    ps.world.collision_objects += psw.collision_objects
            robot_scene.set_scene(ps)
            self.robot_scene_is_diff[robot_name] = False

    def public_scene_is_diff(self, robot_name):
        return self.robot_scene_is_diff[robot_name]

    def is_colliding(self, robot_name, traj):
        # add collision detection here
        return False # return true for testing

    # def broadcast_scene(self):
    # broadcast specified scene to other scene in robot_scenes

class SolDualArm(object):
    left_arm=None
    right_arm=None
    def __init__(self,ns_robot0="robot0", ns_robot1="robot1"): 
        self.sol_sco =None# SolSceneCollisionObjectManager()
        # node_names = rosnode.get_node_names()
        # move_group_names = [name for name in node_names if re.search('move_group$', name)]
        # move_group_ns = ['/'.join(ns.split('/')[1:-1]) for ns in move_group_names]
        # move_group_ns.sort()
        # ns_robot0 =  move_group_ns[0] 
        # ns_robot1 =  move_group_ns[1] 
        # print("==>node_names=",node_names)
        # print("==>move_group_names=",move_group_names)
        # print("==>move_group_ns=",move_group_ns)
        if not SolRobot._is_initialized:
            print("init left_arm ...")
            #left_arm
            SolDualArm.left_arm=SolRobot( ns=ns_robot0)
            print("left_arm ready!")

            print("init right_arm ...")
            #right_arm
            SolDualArm.right_arm=SolRobot(ns=ns_robot1)
            print("right_arm ready!")
    
            self.debug_name="Debug Dual Arm"

        #self.go_home()


        # #bounding UR10 boxes
        # self.left_current_jv = self.left_arm.move_group.get_current_joint_values()
        # self.left_arm_link_names = self.left_arm.link_names
        # self.left_arm_link_dims = self.compute_collision_object_dims(self.left_arm)
        # self.left_arm_tool_dim = self.compute_robot_tool_dim(self.left_arm)
        # self.left_arm_object_type = [SolidPrimitive.CYLINDER]*len(self.left_arm_link_dims)
        # self.left_arm_tool_object_type = SolidPrimitive.CYLINDER
        # self.left_arm.io_id=4

        # #bounding UR5 boxes
        # self.right_current_jv = self.right_arm.move_group.get_current_joint_values()
        # self.right_arm_link_names = self.right_arm.link_names
        # self.right_arm_link_dims = self.compute_collision_object_dims(self.right_arm)
        # self.right_arm_tool_dim = self.compute_robot_tool_dim(self.right_arm)
        # self.right_arm_object_type = [SolidPrimitive.CYLINDER]*len(self.right_arm_link_dims)
        # self.right_arm_tool_object_type = SolidPrimitive.CYLINDER
        # self.right_arm.io_id=4

        # self.sol_sco.add_robot_primitives('robot0',
        #                                   self.left_arm_object_type,
        #                                   self.left_arm_link_dims)
        # self.sol_sco.add_robot_primitives('robot1',
        #                                   self.right_arm_object_type,
        #                                   self.right_arm_link_dims)
        # self.sol_sco.add_robot_tool_primitives('robot0',
        #                                        self.left_arm_tool_object_type,
        #                                        self.left_arm_tool_dim)
        # self.sol_sco.add_robot_tool_primitives('robot1',
        #                                        self.right_arm_tool_object_type,
        #                                        self.right_arm_tool_dim)

        # left_arm_obj_current_pose, left_arm_tool_current_pose = self.compute_collision_object_and_tool_current_poses(self.left_arm)
        # right_arm_obj_current_pose, right_arm_tool_current_pose = self.compute_collision_object_and_tool_current_poses(self.right_arm)
        # self.sol_sco.update_robot_public_scene('robot0', [left_arm_obj_current_pose], [left_arm_tool_current_pose])
        # self.sol_sco.update_robot_public_scene('robot1', [right_arm_obj_current_pose], [right_arm_tool_current_pose])
        # self.detect_object_list = list()
        # self.object_select_tag_list = list()

        # self.target_lock = threading.Lock()
        # self.scene_lock = threading.Lock()
        # self.compute_co_lock = threading.Lock() # collision object


    def plan(self, pose_left,pose_right):
        print("planning for two arms")

    def generate_random_targets(self,N=10):
        targets=[]
        for i in range(N):
            targets.append(Pose(self.bin_center[0]+random.uniform(-0.2,0.2),self.bin_center[1]+random.uniform(-0.2,0.2),0,180,0,0))
        return targets
    def test_print(self):
        print("----------------test print out")
    def go_home(self):
         #left_arm UR10
        self.left_arm.home_joint= [62.52,-101.43,113.52,-102.09,-90,-207.48]  
        self.left_arm.home_joint = [i/180.0*pi for i in self.left_arm.home_joint]    
        #right_arm UR5
        self.right_arm.home_joint=[53,-109.39,-63.54,-97.08,89.76,-36.93] 
        self.right_arm.home_joint = [i/180.0*pi for i in self.right_arm.home_joint]  
          
        #clean
        self.left_arm.clean_planned_path_cubes() 
        self.left_arm.clean_planned_path_cubes(self.right_arm.robot_name) 
        self.right_arm.clean_planned_path_cubes() 
        self.right_arm.clean_planned_path_cubes(self.left_arm.robot_name) 
 
        thd_left = self.left_arm.MoveJ_thread(self.left_arm.home_joint)  
        print("left_arm arrived ur10_home")
        self.right_arm.MoveJ(self.right_arm.home_joint)
        print("right_arm arrives ur5_home")
        thd_left.join()

    def go_goal_joint(self,left_joint,right_joint):
        self.progress=false
        #left_arm UR10
        left_joint_rad= [i/180.0*pi for i in left_joint]    
        #right_arm UR5
        right_joint_rad= [i/180.0*pi for i in right_joint]           
        self.left_arm.MoveJ(left_joint_rad)  
        #thd_left = self.left_arm.MoveJ_thread(left_joint_rad)  
        print("left_arm arrived ur10_home")
        self.right_arm.MoveJ(right_joint_rad)
        print("right_arm arrives ur5_home")
        #thd_left.join()
        self.progress=true

    def compute_collision_object_and_tool_current_poses(self, sol_robot):
        jtp = JointTrajectoryPoint()
        jtp.positions = sol_robot.move_group.get_current_joint_values()
        poses, _ = self.compute_collision_object_poses_lengths(sol_robot, jtp)
        tool_pose, _ = self.compute_robot_tool_pose_length(sol_robot, jtp)
        return poses, tool_pose

    def compute_collision_object_dims(self, sol_robot, radius = 0.055):
        dims = list()
        jtp = JointTrajectoryPoint()
        jtp.positions = sol_robot.move_group.get_current_joint_values()
        _, lengths = self.compute_collision_object_poses_lengths(sol_robot, jtp)
        if isinstance(radius, (int, float)):
            dims = [(length, radius) for length in lengths]
        elif isinstance(radius, list):
            if not(len(radius) == len(lengths)):
                raise Exception("input radius list size is incorrect")
            for i in range(len(lengths)):
                dims.append((length[i], radius[i]))
        return dims

    def compute_robot_tool_dim(self, sol_robot, radius = 0.011):
        dim = list()
        jtp = JointTrajectoryPoint()
        jtp.positions = sol_robot.move_group.get_current_joint_values()
        _, length = self.compute_robot_tool_pose_length(sol_robot, jtp)

        if isinstance(radius, (int, float)):
            dim = (length, radius)
        else:
            raise Exception("input tool radius type is incorrect")
        return dim

    def compute_collision_object_and_tool_poses_list(self, sol_robot, traj):
        # traj: RobotTrajectory
        poses_list = list() # 2-D array
        tool_pose_list= list()
        thd_list = list()

        for jtp in traj.joint_trajectory.points:
            thd = threading.Thread(target=self.compute_collision_object_and_tool_poses_thread,
                                   args=(sol_robot, jtp, poses_list, tool_pose_list,))
            thd_list.append(thd)
            # poses, _ = self.compute_collision_object_poses_lengths(sol_robot, jtp)
            # poses_list.append(poses)
            # tool_pose = self.compute_robot_tool_pose(sol_robot, joint_point, tool0_name, tcp0_name)
            # tool_pose_list.append(tool_pose)

        for thd in thd_list:
            thd.start()

        for thd in thd_list:
            thd.join()

        return poses_list, tool_pose_list

    def compute_collision_object_and_tool_poses_thread(self, sol_robot, joint_point, poses_list_ref, tool_pose_list_ref = None):
        poses, _ = self.compute_collision_object_poses_lengths(sol_robot, joint_point)
        poses_list_ref.append(poses)

        if tool_pose_list_ref is not None:
            pose, _ = self.compute_robot_tool_pose_length(sol_robot, joint_point)
            tool_pose_list_ref.append(pose)

    def compute_collision_object_poses_lengths(self, sol_robot, joint_point):
        poses = list()
        lengths = list()
        link_names = sol_robot.link_names
        res = sol_robot.call_compute_fk(joint_point.positions, link_names) # pose stamped list

        for i, link_name in enumerate(link_names[0:-1]):
            obj_pose = geometry_msgs.msg.PoseStamped()
            obj_pose.header = res[i].header
            obj_pose.header.frame_id = "world"

            vec_x = res[i+1].pose.position.x - res[i].pose.position.x
            vec_y = res[i+1].pose.position.y - res[i].pose.position.y
            vec_z = res[i+1].pose.position.z - res[i].pose.position.z
            vec = np.array([vec_x, vec_y, vec_z])
            length = np.linalg.norm(vec)
            world_z = [0, 0, 1]
            frame_z = vec/length # unit vector

            frame_y = np.cross(frame_z, world_z)
            if np.linalg.norm(frame_y) > sys.float_info.epsilon:
                frame_x = np.cross(frame_y, frame_z)
            else:
                world_x = [1, 0, 0]
                frame_y = np.cross(frame_z, world_x)
                frame_x = np.cross(frame_y, frame_z)

            # set to unit vector
            frame_x = frame_x/np.linalg.norm(frame_x)
            frame_y = frame_y/np.linalg.norm(frame_y)

            # set cylinder pose
            pose_mat = np.identity(4)
            pose_mat[0:-1, 0] = frame_x
            pose_mat[0:-1, 1] = frame_y
            pose_mat[0:-1, 2] = frame_z
            pose_mat[0:-1, 3] = [res[i].pose.position.x + vec_x/2,
                                 res[i].pose.position.y + vec_y/2,
                                 res[i].pose.position.z + vec_z/2]

            obj_pose.pose = pose_2_geometry_msgs_Pose(pose_mat)
            poses.append(obj_pose)
            lengths.append(length)

        return poses, lengths

    def compute_robot_tool_pose_length(self, sol_robot, joint_point, tool0_name = 'tool0', tcp0_name = 'tcp0'):
        robot_tool0_name = sol_robot.robot_name + '/' + tool0_name
        robot_tcp0_name = sol_robot.robot_name + '/' + tcp0_name 
        res = sol_robot.call_compute_fk(joint_point.positions, [robot_tool0_name, robot_tcp0_name]) # pose stamped list

        obj_pose = geometry_msgs.msg.PoseStamped()
        obj_pose.header = res[-1].header
        obj_pose.header.frame_id = "world"

        vec_x = res[-1].pose.position.x - res[0].pose.position.x
        vec_y = res[-1].pose.position.y - res[0].pose.position.y
        vec_z = res[-1].pose.position.z - res[0].pose.position.z
        vec = np.array([vec_x, vec_y, vec_z])
        length = np.linalg.norm(vec)

        tool_pose = res[-1].pose
        tool_pose.position.x -= vec_x/2
        tool_pose.position.y -= vec_y/2
        tool_pose.position.z -= vec_z/2

        obj_pose.pose = tool_pose

        return obj_pose, length


    def test_hexagon(self,N=6,radius=0.2): 
        #hexagon  
        target_left= Pose(0.6,0.1,0.4,0,90,0) 
        target_right= Pose(0.7,0.1,0.4,0,-90,0)   
        self.left_arm.MoveL(target_left)
        self.right_arm.MoveL(target_right)

        # pose1=geometry_msgs_Pose_2_pose(self.move_group.get_current_pose().pose)
        # for i in range(N+1): 
        #     ang = i*2*pi/N #angle: 0, 60, 120, ... 
        #     posei = pose1*rotz(ang)*transl(radius,0,0)*rotz(-ang) 
        #     self.MoveL(posei)
    
    def test_move(self):
        #left_arm UR10
        ur10_home_degree=[62.52,-101.43,113.52,-102.09,-90,-207.48]#
        ur10_home = [i/180.0*pi for i in ur10_home_degree]    
        #right_arm UR5
        ur5_home_degree=[53,-109.39,-63.54,-97.08,89.76,-36.93] 
        ur5_home = [i/180.0*pi for i in ur5_home_degree]  
        
        #hexagon  
        test_poseUR10= Pose(0.5,0.6,0.3,180,0,0) 
        test_poseUR5= Pose(0.7,0.6,0.3,180,0,0)    
        for i in range(1):  
            #clean
            self.left_arm.clean_planned_path_cubes() 
            self.left_arm.clean_planned_path_cubes(self.right_arm.robot_name) 
            self.right_arm.clean_planned_path_cubes() 
            self.right_arm.clean_planned_path_cubes(self.left_arm.robot_name) 

 
            test_poseUR10= Pose(0.5,0.5+random.uniform(-0.15,0.15),0.3,180,0,0) 
            test_poseUR5= Pose(0.7,0.5+random.uniform(-0.2,0.2),0.3,180,0,0)   
            self.left_arm.markers.deleteAllMarkers()
            self.left_arm.MoveJ_thread(ur10_home)  
            print("left_arm arrived ur10_home") 
            dual_arm.right_arm.MoveJ(ur5_home)
            print("right_arm arrives ur5_home") 
 
            self.left_arm.recent_path=[]
            self.right_arm.recent_path=[]

            self.left_arm.add_robot_bounding(dual_arm.left_arm_link_names,dual_arm.left_arm_link_offsets, dual_arm.left_arm_link_dims,dual_arm.right_arm.scene)
            self.right_arm.add_robot_bounding(dual_arm.right_arm_link_names,dual_arm.right_arm_link_offsets, dual_arm.right_arm_link_dims,dual_arm.left_arm.scene)
            
            #Move first arm
            #dual_arm.left_arm.MoveL_thread(test_poseUR10)  
            self.left_arm.get_planning_a_target(test_poseUR10)
            
            #generate cubes from left robot to right robot
            #dual_arm.left_arm.add_joint_path_2_scene(dual_arm.left_arm_link_names,dual_arm.left_arm_link_offsets, dual_arm.left_arm_link_dims)
            self.left_arm.add_joint_path_2_scene(dual_arm.left_arm_link_names,dual_arm.left_arm_link_offsets, dual_arm.left_arm_link_dims,dual_arm.right_arm.scene)
    
            #dual_arm.left_arm.MoveL_thread(test_poseUR10)  
            self.right_arm.get_planning_a_target(test_poseUR5)

            #clean
            self.left_arm.clean_planned_path_cubes() 
            self.right_arm.clean_planned_path_cubes() 

            self.left_arm.display_path()
            self.right_arm.display_path()
            #move second arm
            # dual_arm.right_arm.MoveL(test_poseUR5)  
            self.left_arm.execute_planned_trajectory_thread()
            self.right_arm.execute_planned_trajectory()
            
        
        print("FINISHED!")
    
    def clear_cubes(self):
        self.left_arm.clean_planned_path_cubes() 
        self.left_arm.clean_planned_path_cubes(self.right_arm.robot_name) 
        self.right_arm.clean_planned_path_cubes() 
        self.right_arm.clean_planned_path_cubes(self.left_arm.robot_name) 

    def clear_octomap(self):
        # self.left_arm.clear_octomap()
        # self.right_arm.clear_octomap()
        print("Reset Octomap...")
        rospy.sleep(.1)

    def reverse_a_trajectory(self,input_traj):
        reverse_traj=copy.deepcopy(input_traj)
        reverse_traj.joint_trajectory.points.reverse()
        for i, pt in enumerate(reverse_traj.joint_trajectory.points):
            pt.time_from_start = abs(input_traj.joint_trajectory.points[-1].time_from_start - input_traj.joint_trajectory.points[-1-i].time_from_start)
            pt.velocities = [-vel for vel in pt.velocities]
            pt.accelerations = [-acc for acc in pt.accelerations]
        return reverse_traj

    def concate_multiple_trajectory(self,input_traj_list):
        input_trajs = [copy.deepcopy(input_traj) for input_traj in input_traj_list]
        traj_out = copy.deepcopy(input_trajs[0])
        del traj_out.joint_trajectory.points[:]
        last_end_time = rospy.Duration(0)

        for i, traj in enumerate(input_trajs):
            if i > 0:
                del traj.joint_trajectory.points[0]
            for j, pt in enumerate(traj.joint_trajectory.points):
                pt.time_from_start += last_end_time
                traj.joint_trajectory.points[j] = pt
            traj_out.joint_trajectory.points += traj.joint_trajectory.points
            last_end_time = traj_out.joint_trajectory.points[-1].time_from_start
        return traj_out

    def arm_execute_sync(self, robot_name, sol_robot):
        while True:
            # get target
            self.target_lock.acquire()
            target_pose, target_index = self.get_target_test(sol_robot)
            self.target_lock.release()
            if target_pose is None:
                continue

            # plan trajectory
            self.scene_lock.acquire()
            self.sol_sco.set_public_scene_to_robot(robot_name, sol_robot.scene, True)
            pick, place = self.traj_generator_test(sol_robot, target_pose)
            if pick is None or place is None:
                print("[arm_execute] " + robot_name + " plan fail")
            else:
                # visualize trajectory for debug
                if robot_name=='robot0':
                    sol_robot.display_rviz_traj(pick, 'arm0')
                elif robot_name=='robot1':
                    sol_robot.display_rviz_traj(pick, 'arm1')

                # scene manager
                # self.scene_lock.acquire()
                if self.sol_sco.public_scene_is_diff(robot_name):
                    self.sol_sco.set_public_scene_to_robot(robot_name, sol_robot.scene, True)
                    print("set_public_scene_to_robot")
                    if self.sol_sco.is_colliding(robot_name, pick):
                        pass
                        #re-plan
                    else:
                        poses_list = self.compute_collision_object_poses_list(sol_robot, pick)
                        self.sol_sco.update_robot_public_scene(robot_name, poses_list)
                        self.sol_sco.set_public_scene_to_robot(robot_name, sol_robot.scene, True)
                else:
                    poses_list = self.compute_collision_object_poses_list(sol_robot, pick)
                    self.sol_sco.update_robot_public_scene(robot_name, poses_list)
                    self.sol_sco.set_public_scene_to_robot(robot_name, sol_robot.scene, True)
                    print("update_robot_public_scene")
                # self.scene_lock.release()
            self.scene_lock.release()

            rospy.sleep(0.01)

            # rospy.spin()
            # robot execute
            # sol_robot.execute_planned_trajectory(pick, False)
            # sol_robot.execute_planned_trajectory(place, False)
            # sol_robot.execute_planned_trajectory(pick, True)
            # sol_robot.execute_planned_trajectory(place, True)

    # todo: implement fsm in C++
    # the function wouldn't plan trajectory with other thread at the same time
    def arm_execute(self, robot_name, sol_robot):
        while True:
            # get target
            self.target_lock.acquire()
            target_pose, target_index = self.get_target_test(sol_robot)
            self.target_lock.release()
            if target_pose is None:
                # todo: get detect proxy again if target is empty but task isn't finish yet
                print("[arm_execute] target is None")
                break
                # continue

            # t_start = time.time()#!
            self.scene_lock.acquire() # locked
            sol_robot.clear_octomap()
            rospy.sleep(.1)
            # plan trajectory
            self.sol_sco.set_public_scene_to_robot(robot_name, sol_robot.scene, True)
            pick, place = self.traj_generator_test(sol_robot, target_pose)
            if pick is None or place is None:
                print("[arm_execute] " + robot_name + " plan fail")
                self.scene_lock.release()
                continue
            else:
                #! visualize trajectory for debug
                if robot_name=='robot0':
                    sol_robot.display_rviz_traj(pick, 'arm0')
                elif robot_name=='robot1':
                    sol_robot.display_rviz_traj(pick, 'arm1')
                # scene manager
                poses_list, tool_pose_list = self.compute_collision_object_and_tool_poses_list(sol_robot, pick)
                self.sol_sco.update_robot_public_scene(robot_name, poses_list, tool_pose_list)
            self.scene_lock.release() # unlocked
            # t_end = time.time()#!
            # print(robot_name+" [arm_execute] It cost %f sec" % (t_end - t_start))#!

            # rospy.sleep(5)
            # rospy.sleep(0.1)

            # robot execute
            # sol_robot.execute_planned_trajectory(pick, False)
            # sol_robot.execute_planned_trajectory(place, False)
            sol_robot.execute_planned_trajectory(pick, True)
            sol_robot.io.digital(sol_robot.io_id, 1)
            sol_robot.execute_planned_trajectory(place, True)
            sol_robot.io.digital(sol_robot.io_id, 0)
            # sol_robot.execute_planned_trajectory(pick_place, False)
            # sol_robot.execute_planned_trajectory(pick_place, True)

    def arm_execute_thread(self, robot_name, sol_robot):
        x = threading.Thread(target=self.arm_execute, args=(robot_name, sol_robot,))
        x.start()
        return x

    def get_target_test(self, sol_robot):
        #bin center
        bx=sol_robot.bin_right_center[0]
        by=sol_robot.bin_right_center[1]
        bz=sol_robot.bin_right_center[2]
        # global current_objects 

        object_available=False
       
        target=None
        while (object_available is False):
            if not (len(self.detect_object_list) > 0):
                # call service
                print("call service...........................")
                res=None
                res = sol_robot.detect_proxy()
                self.detect_object_list = res.result.detections
                self.object_select_tag_list = [False]*len(self.detect_object_list)
                sol_robot.detected_targets=[]
            current_objects = self.detect_object_list
            select_tag = self.object_select_tag_list
            max_z_index=-1
            max_z_value=-1000000
            
            for i in range(len(current_objects)):
                if not select_tag[i]:
                    x=current_objects[i].results[0].pose.pose.position.x
                    y=current_objects[i].results[0].pose.pose.position.y 
                    z=current_objects[i].results[0].pose.pose.position.z 

                    if ((bx-x)*(bx-x) <0.35*0.35) and ((by-y)*(by-y) <0.25*0.25)  and  z>(bz) and  z<0.2:
                        sol_robot.detected_targets.append(geometry_msgs_Pose_2_pose(current_objects[i].results[0].pose.pose))
                        if (-abs(sol_robot.world2robot.Pos()[0]-x)>max_z_value):
                            max_z_index=i
                            max_z_value=-abs(sol_robot.world2robot.Pos()[0]-x)
                            target=geometry_msgs_Pose_2_pose(current_objects[i].results[0].pose.pose)
            if max_z_index > -1:
                select_tag[max_z_index] = True
                self.object_select_tag_list = select_tag

            if target is not None:
                #dipslay Picking obj
                # sol_robot.markers.publishAxis(target, 0.2, 0.02, 500.0)
                # sol_robot.markers.publishText(target ,sol_robot.robot_name+" pick1",'yellow', Vector3Geometry(0.1,0.1,0.1), 500.0)
                print("object available!")
            object_available=True
        return target, max_z_index

    def traj_generator_test(self, sol_robot, target_pose):
        sol_robot.markers.deleteAllMarkers()
        print('plan joint path')
        traj_pick = None
        traj_place = None
        robot_traj = None
        robot_cart_traj = None

        robot_traj = sol_robot.get_path_joint_2_target(sol_robot.home_joint,transl(0,0,0.06).__mul__(target_pose), True)
        if robot_traj is not None:
            robot_cart_traj = sol_robot.get_path_joint_2_target_cartesian(robot_traj.joint_trajectory.points[-1].positions, transl(0,0,0.02).__mul__(target_pose), True)

        if robot_traj is None or robot_cart_traj is None:
            print("robot traj is None")

        if (robot_traj is not None and robot_cart_traj is not None):
            robot_traj_reverse=self.reverse_a_trajectory(robot_traj)
            robot_cart_traj_reverse=self.reverse_a_trajectory(robot_cart_traj)
            traj_list_pick = [robot_traj, robot_cart_traj]
            traj_list_place = [robot_cart_traj_reverse, robot_traj_reverse]
            traj_pick = self.concate_multiple_trajectory(traj_list_pick)
            traj_place = self.concate_multiple_trajectory(traj_list_place)

        return traj_pick, traj_place
 
   
     