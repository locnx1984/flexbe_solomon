#!/usr/bin/env python
# -*- coding: utf-8 -*-
###########################################################
#               WARNING: Generated code!                  #
#              **************************                 #
# Manual changes may get lost if file is generated again. #
# Only code inside the [MANUAL] tags will be kept.        #
###########################################################

from flexbe_core import Behavior, Autonomy, OperatableStateMachine, ConcurrencyContainer, PriorityContainer, Logger
from flexbe_states.wait_state import WaitState
from flexbe_states.log_state import LogState
from vigir_flexbe_states.current_joint_positions_state import CurrentJointPositionsState
# Additional imports can be added inside the following tags
# [MANUAL_IMPORT]

from flor_control_msgs.msg import FlorRobotStatus
from flexbe_core.proxy import ProxySubscriberCached

# [/MANUAL_IMPORT]


'''
Created on Tue Oct 20 2020
@author: sss
'''
class test_atlasSM(Behavior):
	'''
	s
	'''


	def __init__(self):
		super(test_atlasSM, self).__init__()
		self.name = 'test_atlas'

		# parameters of this behavior

		# references to used behaviors

		# Additional initialization code can be added inside the following tags
		# [MANUAL_INIT]

		self._status_topic = '/flor/controller/robot_status'
		self._sub =  ProxySubscriberCached({self._status_topic: FlorRobotStatus})
		self._sub.make_persistant(self._status_topic)
		
		# [/MANUAL_INIT]

		# Behavior comments:



	def create(self):
		# x:30 y:365, x:130 y:365
		_state_machine = OperatableStateMachine(outcomes=['finished', 'failed'])

		# Additional creation code can be added inside the following tags
		# [MANUAL_CREATE]
		
		# [/MANUAL_CREATE]


		with _state_machine:
			# x:30 y:40
			OperatableStateMachine.add('w1',
										WaitState(wait_time=2),
										transitions={'done': 'print1'},
										autonomy={'done': Autonomy.Off})

			# x:276 y:82
			OperatableStateMachine.add('print1',
										LogState(text="ooo", severity=Logger.REPORT_HINT),
										transitions={'done': 'cr'},
										autonomy={'done': Autonomy.Off})

			# x:718 y:94
			OperatableStateMachine.add('cr',
										CurrentJointPositionsState(planning_group=/robot0/move_group),
										transitions={'retrieved': 'finished', 'failed': 'failed'},
										autonomy={'retrieved': Autonomy.Off, 'failed': Autonomy.Off},
										remapping={'joint_positions': 'joint_positions'})


		return _state_machine


	# Private functions can be added inside the following tags
	# [MANUAL_FUNC]
	 

	# [/MANUAL_FUNC]
