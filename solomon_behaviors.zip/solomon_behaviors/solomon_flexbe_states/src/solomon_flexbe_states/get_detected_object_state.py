#!/usr/bin/env python
# 
# GetDetectedObjectState: Get detected objects from vision system.
#
# Authors: Loc Nguyen 
# Solomon Technology Corp.
# Copyright - 2020 
# 
# The software contains proprietary information of Solomon Technology Corp.  
# It is provided under a license agreement containing restrictions on use and disclosure 
# and is also protected by copyright law. Reverse engineering of the software is prohibited. 
# 
# No part of this publication may be reproduced, stored in a retrieval system, 
# or transmitted in any form or by any means, electronic, mechanical, photocopying, recording or otherwise 
# without the prior written permission of Solomon Technology Corp. 
#  

import rospy
from flexbe_core import EventState, Logger 
from flexbe_core.proxy.proxy_service_caller import ProxyServiceCaller  
from solomon_msgs.srv import VisionDetect,VisionDetectRequest,VisionDetectResponse 

class GetDetectedObjectState(EventState):
	'''
	Get detected objects from vision system by a service topic.

	-- service_topic 		service name for clearing octomap

	#> camera_img 	Image 	The current color image of the left camera.
	># camera_img 	Image 	The current color image of the left camera.

	<= done 				Image data is available.

	'''
	def __init__(self,service_topic):
		'''Constructor'''
		super(GetDetectedObjectState, self).__init__(outcomes = ['done','failed'],
														output_keys = ['detected_objects']) 
	 	self._srv_topic = service_topic 
		self._srv = ProxyServiceCaller({self._srv_topic: VisionDetect},wait_duration=300)  #5 minute wait
		self._success=False
		self.srv_result=None

	def execute(self, userdata):  
		Logger.loginfo("execute: detect objects!")
		if (self._success):
			return 'done' 
		else:
			return 'failed'
	
	def on_enter(self, userdata):		
		try:
			if self._srv.is_available(self._srv_topic):
				Logger.loginfo("Vision Service is available")  
				#PROXY CALLER
				self.srv_result = self._srv.call(self._srv_topic,VisionDetectRequest())  
				if (self.srv_result is not None):
					Logger.loginfo('Total detected objects:%d' %len( self.srv_result.result.detections))
					userdata.detected_objects= self.srv_result
					self._success=True	
				else:		
					Logger.loginfo("result of Vision Service is None")   
					self._success=False	 
			else:
				Logger.loginfo("Vision Service is NOT available")   
				self._success=False
		except Exception as e:
			Logger.logwarn('Failed to receive service call:\n%s ' % str(e))
			Logger.logwarn(' service call: srv_result=\n%s ' % self.srv_result)
			self._success=False
		
 
		