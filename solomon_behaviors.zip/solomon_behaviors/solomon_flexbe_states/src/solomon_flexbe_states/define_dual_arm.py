#!/usr/bin/env python

import rospy

from flexbe_core import EventState, Logger

from flexbe_core.proxy import ProxySubscriberCached 
import sys 
# print(sys.path) 
# Not working in Flexbe
# sys.path.append('../../../../') #for solomon_pack and solomon_functions
# sys.path.append('../../../../../') #for referencing solomon_pack, solomon_functions 
# sys.path.append('../../../') 
# sys.path.append('../../') 
sys.path.append('/media/solomon/28CECBCACECB8F0E3/LOC/DualArm/Solomon_Motion_Planning/src/')  

from Robots.solrobot_class import SolRobot,SolDualArm  #run in terminal
#from src.solomon_behaviors.solomon_flexbe_states.src.solomon_flexbe_states.Robots.solrobot_class import SolRobot,SolDualArm
'''
Created on 10/15/2020

@author: Loc Nguyen
'''
class DefineDualArmState(EventState):
	'''
	Grabs the most recent camera image.

	#> camera_img 	Image 	The current color image of the left camera.

	<= done 				Image data is available.

	'''

	def __init__(self):
		'''Constructor'''
		super(DefineDualArmState, self).__init__(outcomes = ['done'])#,
														#input_keys = ['left_arm_name','right_arm_name'])
		 
		

	def execute(self, userdata): 
		return 'done'


	def on_enter(self, userdata): 
		
		Logger.loginfo("enter.. ")  

	def on_start(self, userdata):
		dual_arm=SolDualArm(ns_robot0='robot0', ns_robot1='robot1')
         
		#userdata.dual_arm.go_home()
		Logger.loginfo("Dual Arm is created ")  
		
	def on_stop(self, userdata): 
		dual_arm=None
		Logger.loginfo("Dual Arm is deleted ")  
		
 