#!/usr/bin/env python
# -*- coding: utf-8 -*-
###########################################################
#               WARNING: Generated code!                  #
#              **************************                 #
# Manual changes may get lost if file is generated again. #
# Only code inside the [MANUAL] tags will be kept.        #
###########################################################

from flexbe_core import Behavior, Autonomy, OperatableStateMachine, ConcurrencyContainer, PriorityContainer, Logger
from solomon_flexbe_states.clear_octomap import ClearOctomapState
from solomon_flexbe_states.movej_robot_state import MoveJRobotState
from flexbe_states.wait_state import WaitState
# Additional imports can be added inside the following tags
# [MANUAL_IMPORT]

# [/MANUAL_IMPORT]


'''
Created on Mon Oct 19 2020
@author: Loc
'''
class Test_SolRobotSM(Behavior):
	'''
	Test_SolRobot
	'''


	def __init__(self):
		super(Test_SolRobotSM, self).__init__()
		self.name = 'Test_SolRobot'

		# parameters of this behavior

		# references to used behaviors

		# Additional initialization code can be added inside the following tags
		# [MANUAL_INIT]
		
		# [/MANUAL_INIT]

		# Behavior comments:



	def create(self):
		# x:793 y:49, x:775 y:205
		_state_machine = OperatableStateMachine(outcomes=['finished', 'failed'])
		_state_machine.userdata.Right_Arm = None
		_state_machine.userdata.Left_Arm = None
		_state_machine.userdata.Left_Arm_Str = "robot0"
		_state_machine.userdata.Right_Arm_Str = "robot1"
		_state_machine.userdata.input_value = 0
		_state_machine.userdata.joints = [0,0,-0.3,0,0,0]

		# Additional creation code can be added inside the following tags
		# [MANUAL_CREATE]
		
		# [/MANUAL_CREATE]


		with _state_machine:
			# x:30 y:102
			OperatableStateMachine.add('clear0',
										ClearOctomapState(service_topic="/robot0/clear_octomap", times=3),
										transitions={'done': 'clear1', 'failed': 'clear1'},
										autonomy={'done': Autonomy.Off, 'failed': Autonomy.Off})

			# x:30 y:194
			OperatableStateMachine.add('clear1',
										ClearOctomapState(service_topic="/robot1/clear_octomap", times=3),
										transitions={'done': 'movej', 'failed': 'movej'},
										autonomy={'done': Autonomy.Off, 'failed': Autonomy.Off})

			# x:326 y:369
			OperatableStateMachine.add('movej',
										MoveJRobotState(),
										transitions={'done': 'wait2s'},
										autonomy={'done': Autonomy.Off},
										remapping={'robot_name': 'Left_Arm_Str', 'joints': 'joints'})

			# x:559 y:204
			OperatableStateMachine.add('wait2s',
										WaitState(wait_time=3),
										transitions={'done': 'finished'},
										autonomy={'done': Autonomy.Off})


		return _state_machine


	# Private functions can be added inside the following tags
	# [MANUAL_FUNC]
	
	# [/MANUAL_FUNC]
