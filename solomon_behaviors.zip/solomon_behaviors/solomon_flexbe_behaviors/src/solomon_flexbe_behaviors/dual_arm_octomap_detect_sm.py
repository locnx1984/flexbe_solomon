#!/usr/bin/env python
# -*- coding: utf-8 -*-
###########################################################
#               WARNING: Generated code!                  #
#              **************************                 #
# Manual changes may get lost if file is generated again. #
# Only code inside the [MANUAL] tags will be kept.        #
###########################################################

from flexbe_core import Behavior, Autonomy, OperatableStateMachine, ConcurrencyContainer, PriorityContainer, Logger
from flexbe_states.log_state import LogState
from flexbe_states.wait_state import WaitState
from solomon_flexbe_states.get_2D_image_state import Get2DImageState
from solomon_flexbe_states.clear_octomap import ClearOctomapState
from solomon_flexbe_states.get_detected_object_state import GetDetectedObjectState
from solomon_flexbe_states.display_detected_objects_state import DisplayDetectedObjectState
# Additional imports can be added inside the following tags
# [MANUAL_IMPORT]

# [/MANUAL_IMPORT]


'''
Created on Fri Aug 21 2015
@author: Philipp Schillinger
'''
class Dual_Arm_OctoMap_DetectSM(Behavior):
	'''
	This is a simple example for a behavior.
	'''


	def __init__(self):
		super(Dual_Arm_OctoMap_DetectSM, self).__init__()
		self.name = 'Dual_Arm_OctoMap_Detect'

		# parameters of this behavior
		self.add_parameter('waiting_time', 1)

		# references to used behaviors

		# Additional initialization code can be added inside the following tags
		# [MANUAL_INIT]
		
		# [/MANUAL_INIT]

		# Behavior comments:



	def create(self):
		log_msg = "Hello World Solomon!"
		# x:1047 y:587
		_state_machine = OperatableStateMachine(outcomes=['finished'])

		# Additional creation code can be added inside the following tags
		# [MANUAL_CREATE]
		
		# [/MANUAL_CREATE]


		with _state_machine:
			# x:52 y:78
			OperatableStateMachine.add('Print_Message',
										LogState(text=log_msg, severity=Logger.REPORT_HINT),
										transitions={'done': 'Capture 2D Image'},
										autonomy={'done': Autonomy.Off})

			# x:227 y:154
			OperatableStateMachine.add('Wait_After_Logging',
										WaitState(wait_time=self.waiting_time),
										transitions={'done': 'Clear Octomap 0'},
										autonomy={'done': Autonomy.Off})

			# x:776 y:79
			OperatableStateMachine.add('Capture 2D Image',
										Get2DImageState(image_topic="/camera/color/image_raw"),
										transitions={'done': 'detect'},
										autonomy={'done': Autonomy.Off},
										remapping={'camera_img': 'camera_img'})

			# x:219 y:295
			OperatableStateMachine.add('Clear Octomap 0',
										ClearOctomapState(service_topic="robot0/clear_octomap", times=4),
										transitions={'done': 'Clear Octomap 1', 'failed': 'finished'},
										autonomy={'done': Autonomy.Off, 'failed': Autonomy.Off})

			# x:49 y:454
			OperatableStateMachine.add('Wait',
										WaitState(wait_time=1),
										transitions={'done': 'Print_Message'},
										autonomy={'done': Autonomy.Off})

			# x:800 y:185
			OperatableStateMachine.add('detect',
										GetDetectedObjectState(service_topic="/detect_object"),
										transitions={'done': 'Display Detected Objects', 'failed': 'finished'},
										autonomy={'done': Autonomy.Off, 'failed': Autonomy.Off},
										remapping={'detected_objects': 'detected_objects'})

			# x:230 y:458
			OperatableStateMachine.add('Clear Octomap 1',
										ClearOctomapState(service_topic="robot1/clear_octomap", times=2),
										transitions={'done': 'Print_Message', 'failed': 'finished'},
										autonomy={'done': Autonomy.Off, 'failed': Autonomy.Off})

			# x:570 y:205
			OperatableStateMachine.add('Display Detected Objects',
										DisplayDetectedObjectState(topic='visualization_marker_array', marker_length=0.1, duration=0),
										transitions={'done': 'Clear Octomap 0'},
										autonomy={'done': Autonomy.Off},
										remapping={'detected_objects': 'detected_objects'})


		return _state_machine


	# Private functions can be added inside the following tags
	# [MANUAL_FUNC]
	
	# [/MANUAL_FUNC]
