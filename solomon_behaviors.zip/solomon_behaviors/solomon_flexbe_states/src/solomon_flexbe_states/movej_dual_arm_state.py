#!/usr/bin/env python

import rospy 

import moveit_commander
import sys 
# print(sys.path) 
# Not working in Flexbe
# sys.path.append('../../../../') #for solomon_pack and solomon_functions
# sys.path.append('../../../../../') #for referencing solomon_pack, solomon_functions 
# sys.path.append('../../../') 
sys.path.append('../') 
from flexbe_core import EventState, Logger 
from flexbe_core.proxy import ProxySubscriberCached
sys.path.append('/media/solomon/28CECBCACECB8F0E3/LOC/DualArm/Solomon_Motion_Planning/src/')  

from Robots.solrobot_class import SolRobot,SolDualArm  #run in terminal
#from src.solomon_behaviors.solomon_flexbe_states.src.solomon_flexbe_states.Robots.solrobot_class import SolRobot,SolDualArm
'''
Created on 10/15/2020

@author: Loc Nguyen
'''
class MoveJDualArmState(EventState):
	'''
	move dual arm

	#> dual_arm 	dual arm
    #> left_joint 	left target
    #> right_joint 	right target
	<= done 		motion finished

	'''

	def __init__(self):
		'''Constructor'''
		super(MoveJDualArmState, self).__init__(outcomes = ['done'],
														input_keys = ['dual_arm','left_joint','right_joint'] ) 
		self.finished=False 

	def execute(self, userdata):   
		return 'done'

        #Logger.loginfo("movej is on-going...")
        # self.finished = userdata.dual_arm.progress
        # if self.finished==True:
        #     Logger.loginfo("movej is finished") 
        #     return 'done' 

	def on_enter(self, userdata):   
        #Logger.loginfo('movej is started'
        #userdata['dual_arm'].test_print() 
		pass
        #userdata.dual_arm.go_home()#go_goal_joint([62.52,-101.43,113.52,-102.09,-90,-207.48],[53,-109.39,-63.54,-97.08,89.76,-36.93] )#userdata.left_joint, userdata.right_joint)
        #Logger.loginfo("movej is started %s" %userdata.dual_arm.debug_name)