#!/usr/bin/env python
# -*- coding: utf-8 -*-
###########################################################
#               WARNING: Generated code!                  #
#              **************************                 #
# Manual changes may get lost if file is generated again. #
# Only code inside the [MANUAL] tags will be kept.        #
###########################################################

from flexbe_core import Behavior, Autonomy, OperatableStateMachine, ConcurrencyContainer, PriorityContainer, Logger
from flexbe_states.wait_state import WaitState
from flexbe_states.log_state import LogState
from flexbe_states.check_condition_state import CheckConditionState
# Additional imports can be added inside the following tags
# [MANUAL_IMPORT]

# [/MANUAL_IMPORT]


'''
Created on Thu Oct 29 2020
@author: a
'''
class test1SM(Behavior):
	'''
	a
	'''


	def __init__(self):
		super(test1SM, self).__init__()
		self.name = 'test1'

		# parameters of this behavior

		# references to used behaviors

		# Additional initialization code can be added inside the following tags
		# [MANUAL_INIT]
		
		# [/MANUAL_INIT]

		# Behavior comments:



	def create(self):
		# x:30 y:365, x:542 y:483
		_state_machine = OperatableStateMachine(outcomes=['finished', 'failed'])
		_state_machine.userdata.input_value = 1

		# Additional creation code can be added inside the following tags
		# [MANUAL_CREATE]
		
		# [/MANUAL_CREATE]


		with _state_machine:
			# x:284 y:188
			OperatableStateMachine.add('wait2s',
										WaitState(wait_time=2),
										transitions={'done': 'hello'},
										autonomy={'done': Autonomy.Off})

			# x:891 y:405
			OperatableStateMachine.add('print_failed',
										LogState(text="failed", severity=Logger.REPORT_HINT),
										transitions={'done': 'wait2s'},
										autonomy={'done': Autonomy.Low})

			# x:552 y:355
			OperatableStateMachine.add('print_finished',
										LogState(text="finished", severity=Logger.REPORT_HINT),
										transitions={'done': 'wait2s'},
										autonomy={'done': Autonomy.Off})

			# x:703 y:185
			OperatableStateMachine.add('check',
										CheckConditionState(predicate=lambda x: "true" if x>2 else "false"),
										transitions={'true': 'print_finished', 'false': 'print_failed'},
										autonomy={'true': Autonomy.Low, 'false': Autonomy.Low},
										remapping={'input_value': 'input_value'})

			# x:513 y:61
			OperatableStateMachine.add('hello',
										LogState(text="hello", severity=Logger.REPORT_HINT),
										transitions={'done': 'check'},
										autonomy={'done': Autonomy.Low})


		return _state_machine


	# Private functions can be added inside the following tags
	# [MANUAL_FUNC]
	
	# [/MANUAL_FUNC]
