#!/usr/bin/env python 
'''
Created on 10/15/2020

@author: Loc Nguyen
'''
import rospy
from flexbe_core import EventState, Logger 
from flexbe_core.proxy.proxy_service_caller import ProxyServiceCaller
from std_srvs.srv import Empty,EmptyRequest 

class ClearOctomapState(EventState):
	'''
	Clear Octomap of planning scene by a given service topic. Support calling several times in case of octomap update too quickly.

	-- service_topic 		service name for clearing octomap
	-- times				number of times calling the service

	#> input 				Nothing

	<= done 				Octomap is cleared.

	'''

	def __init__(self,service_topic,times):
		'''Constructor'''
		super(ClearOctomapState, self).__init__(outcomes = ['done','failed']) 
		self._srv_topic = service_topic  
		self._srv = ProxyServiceCaller({self._srv_topic: Empty})
		self._times=times

	def execute(self, userdata):
		return 'done' 

	def on_enter(self, userdata):  
		try:
			if self._srv.is_available(self._srv_topic):
				Logger.loginfo("Service is available")  
				for i in range(self._times):
					self._srv.call( self._srv_topic,EmptyRequest())
					Logger.loginfo("clear octomap %d" %(i+1)) 
			else:
				Logger.loginfo("Service is NOT available") 

			Logger.loginfo("clear octomap...")
		except rospy.ServiceException, e:
			Logger.loginfo("octomap service call failed: %s"%e)
		except rospy.ServiceException, e:
			Logger.loginfo("Error: octomap service not available...: %s"%e)
			return 'failed' 
		