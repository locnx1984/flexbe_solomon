#!/usr/bin/env python

import rospy 
import numpy as np
import moveit_commander
import sys 
# print(sys.path) 
# Not working in Flexbe
# sys.path.append('../../../../') #for solomon_pack and solomon_functions
# sys.path.append('../../../../../') #for referencing solomon_pack, solomon_functions 
# sys.path.append('../../../') 
sys.path.append('../') 
from flexbe_core import EventState, Logger 
from flexbe_core.proxy import ProxySubscriberCached
sys.path.append('/media/solomon/28CECBCACECB8F0E3/LOC/DualArm/Solomon_Motion_Planning/src/')  

from Robots.solrobot_class import SolRobot,SolDualArm  #run in terminal
#from src.solomon_behaviors.solomon_flexbe_states.src.solomon_flexbe_states.Robots.solrobot_class import SolRobot,SolDualArm
'''
Created on 10/15/2020

@author: Loc Nguyen
'''
class MoveJRobotState(EventState):
    '''
    move dual arm

    #> robot 	SolRobot
    #> left_joint 	left target 
    <= done 		motion finished

    '''

    def __init__(self):
        '''Constructor'''
        super(MoveJRobotState, self).__init__(outcomes = ['done'],
                                                        input_keys = ['robot_name','joints'] ) 
        self.finished=False 

    def execute(self, userdata):   
        return 'done'
 

    def on_enter(self, userdata):   
        robot=SolRobot(userdata.robot_name)
        Logger.loginfo("movej is started %s" %userdata.joints)

        Logger.loginfo("robot info: jointnames= %s" %robot.joint_names)  
        robot.print_out()
        robot.MoveJ(np.array(userdata.joints))
        